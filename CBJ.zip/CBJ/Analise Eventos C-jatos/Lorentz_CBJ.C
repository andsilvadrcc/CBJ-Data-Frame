#include "TCanvas.h"
#include "TStyle.h"
#include "TH1.h"
#include "TGaxis.h"
#include "TLatex.h"
#include "TROOT.h"
#include "TGraphErrors.h"
#include "TF1.h"
#include "TLegend.h"
#include "TArrow.h"
#include <math.h>
#include "readevento2.C"
#include "WriteTxt.C"
#include "TFile.h"
#include "TTree.h"

// ROOT, for saving Pythia events as trees in a file.
#include "TTree.h"
#include "TFile.h"

//gStyle->SetOptStat(000000); //NOT put subtitles on the graphics.
    

//  Transformação de Lorentz (geral em todas as direções)...

    Double_t* BOOST(Double_t betax,Double_t betay,Double_t betaz,Double_t px,Double_t py,Double_t pz,Double_t E1){
     
        //Array Elements of the matrix of Lorentz:
        Double_t A00, A11, A22, A33, A01, A02, A03, A12, A13, A23, beta;

        //Speed Parameter
        beta = sqrt(pow(betax,2)+pow(betay,2)+pow(betaz,2));
        
        // Lorentz Factor.
        Double_t gama = pow(1-(beta*beta),-0.5);
        
        //gama:
        A00 = gama;
        if(beta !=0){
            //Symmetrical elements of the matrix:
            A01 = -1*(betax*gama);
            A02 = -1*(betay*gama);
            A03 = -1*(betaz*gama);

            //Elements outside the diagonal:
            A12 = (gama-1)*((betax*betay)/(beta*beta));
            A13 = (gama-1)*((betax*betaz)/(beta*beta));
            A23 = (gama-1)*((betay*betaz)/(beta*beta));


            //Elements of the diagonal:
            A11 = (1+((gama-1)*((betax*betax)/(beta*beta))));
            A22 = (1+((gama-1)*((betay*betay)/(beta*beta))));
            A33 = (1+((gama-1)*((betaz*betaz)/(beta*beta))));
        }else{
            //Elements of the identity matrix:
            A11 = A22 = A33 = 1;
            A12 = A13 = A23 = 0;
            A01 = A02 = A03 = 0;
            
        }
        
        //Lorentz Transformation:
        Double_t P0 = (A00*E1) + (A01*px) + (A02*py) + (A03*pz);              
        Double_t P1 = (A01*E1) + (A11*px) + (A12*py) + (A13*pz);
        Double_t P2 = (A02*E1) + (A12*px) + (A22*py) + (A23*pz);
        Double_t P3 = (A03*E1) + (A13*px) + (A23*py) + (A33*pz);
        
        //cout<<" Matriz de Transformação "<<endl;
        //cout<<" "<<A00<<"  "<<A01<<"  "<<A02<<"  "<<A03<<"  "<<endl;
        //cout<<" "<<A01<<"  "<<A11<<"  "<<A12<<"  "<<A13<<"  "<<endl;
        //cout<<" "<<A02<<"  "<<A12<<"  "<<A22<<"  "<<A23<<"  "<<endl;
        //cout<<" "<<A03<<"  "<<A13<<"  "<<A23<<"  "<<A33<<"  "<<endl;
        
        Double_t *vector = (Double_t*)malloc(4*sizeof(Double_t));  

        //return the 4-vector (E,px,py,pz) = (P0,P1,P2,P3).
        vector[0] = P0;
        vector[1] = P1;
        vector[2] = P2;
        vector[3] = P3;

        //return pointer, well done!
        return vector;
    }

    // ****************************************************************

    // Let's begin the function here!
        
    void Lorentz_CBJ(){


    // vector size
    Int_t N = 10000; 
    
    //Precision:
    cout<<fixed;
    cout<<setprecision(10);
    

    //definition  of variables
    Double_t x[N], y[N], eta[N], phi[N], E1[N], PT[N], PX[N], PY[N], PZ[N], theta[N];
    Double_t px, py, pz, pt, e, Eta, Phi, gama, beta, bx,by,bz;
    Double_t *vector, en, Px, Py, Pz, somaEp=0, somaEn=0,somapx=0,somapy=0,somapz =0, somaE=0, Theta, pseudorapidity, norm = 1, scale;
    int id, Nparticles, cont=1, c=1;
    
    // Set up the ROOT TFile and TTree.
    TFile *file = TFile::Open("Dados_de_todos_Eventos_LAB.root","recreate");
    
    //TTRee " T " with the variable of the event
    TTree *T = new TTree("T","Tree");
    
    
    //The Branchs of the TTree "T".
    T->Branch("px",&px);
    T->Branch("py",&py);
    T->Branch("pz",&pz);
    T->Branch("pt",&pt);
    T->Branch("e",&e);
    T->Branch("Eta",&Eta);
    T->Branch("Phi",&Phi);
    
    
    // 82 Events "C-jets" with total 1334 showers in the frame LAB.
    int lNpts = readevento2("Dados_de_todos_Eventos_LAB.txt",x,y,eta,phi,E1,PT);
    
        for (Int_t i=0; i<lNpts; i++) {
        
        theta[i] = 2*TMath::ATan(TMath::Exp(-eta[i]));
        PX[i] = PT[i]*cos(phi[i]);
        PY[i] = PT[i]*sin(phi[i]);
        PZ[i] = E1[i]*cos(theta[i]); 
        
        //Sum E and pz:
        somaE = somaE + E1[i];
        somapx = somapx + PX[i];
        somapy = somapy + PY[i];
        somapz = somapz + PZ[i];
        
        //Variables of the particles 
        px = PX[i];
        py = PY[i];
        pz = PZ[i];
        pt = PT[i];
        e  = E1[i];
        Eta = eta[i];
        Phi = phi[i];
        
        //Fill the TTRee "T"
        T->Fill();
        
        }
        
        //  Write tree.
        T->Print(); // Print the screen (terminal) the information about the TTRee T
        T->Write();
        
    
    cout << " sum px = "<< somapx << " sum py ="<< somapy << " sum pz = " << somapz << " sum E = "<< somaE << " GeV "<< endl;
    
    somapx = somapy = somapz = somaE = 0;
    
    
    
    
    // create one histogram
    TH1F *hist1 = new TH1F("hist1","Multiplicity LAB",100,-20,20);

    
    // Energy Distribution
    TH1F *hist2 = new TH1F("hist2","Energy Distribution LAB",100,-20,20);
    
    
    
    // ************************************************
    

    for(Int_t i=0; i<lNpts; i++) {
        
        hist1->Fill(eta[i]); // LAB 
        
        hist2->Fill(eta[i],E1[i]); // LAB
        
        
        
        
    }
    
    // Tcanvas hist1
    TCanvas *c1 = new TCanvas("c1","Histograms 1 ",600,400);
    c1->SetGrid(1,1);
    c1->SetLogx(0);
    c1->SetLogy(1);

    hist1->SetLineColor(kBlack);
    hist1->GetYaxis()->SetTitle("dN/d#eta");
    hist1->GetXaxis()->SetTitle("#eta ");
    hist1->SetMaximum(1000);
    hist1->Draw();
    

    // draw the legend
    TLegend *legend1a=new TLegend(0.6,1,0.88,0.85);
    legend1a->SetTextFont(72);
    legend1a->SetTextSize(0.04);
    legend1a->AddEntry(hist1,"CBJ Data","lpe");
    legend1a->Draw();


    // Tcanvas hist2
    TCanvas *c2 = new TCanvas("c2","Histograms 2 ",600,400);
    c2->SetGrid(1,1);
    c2->SetLogx(0);
    c2->SetLogy(1);
    
    hist2->SetLineColor(kBlack);
    hist2->GetYaxis()->SetTitle("dE/d#eta [GeV]");
    hist2->GetXaxis()->SetTitle("#eta ");
    hist2->Draw();
    
    // draw the legend
    TLegend *legend4a=new TLegend(0.6,1,0.88,0.85);
    legend4a->SetTextFont(72);
    legend4a->SetTextSize(0.04);
    legend4a->AddEntry(hist2,"CBJ Data","lpe");
    legend4a->Draw();
    
    
    // Set up the ROOT TFile and TTree.
    TFile *file1 = TFile::Open("Dados_de_todos_Eventos_CM.root","recreate");
    
    //TTRee " T " with the variable of the event
    TTree *T1 = new TTree("T1","Tree");
    
    
    //The Branchs of the TTree "T".
    T1->Branch("px",&px);
    T1->Branch("py",&py);
    T1->Branch("pz",&pz);
    T1->Branch("pt",&pt);
    T1->Branch("e",&e);
    T1->Branch("Eta",&Eta);
    T1->Branch("Phi",&Phi);
    
    // 82 Events "C-jets" with total 1334 showers in the frame CM.
    lNpts = readevento2("Dados_de_todos_Eventos_CM.txt",x,y,eta,phi,E1,PT);
    
    
    for (Int_t i=0; i<lNpts; i++) {
        
        theta[i] = 2*TMath::ATan(TMath::Exp(-eta[i]));
        PX[i] = PT[i]*cos(phi[i]);
        PY[i] = PT[i]*sin(phi[i]);
        PZ[i] = E1[i]*cos(theta[i]); 
        
        //Variables of the particles 
        px = PX[i];
        py = PY[i];
        pz = PZ[i];
        pt = PT[i];
        e  = E1[i];
        Eta = eta[i];
        Phi = phi[i];
        
        //Fill the TTRee "T1"
        T1->Fill();
        
        //Sum E and pz:
        somaE = somaE + E1[i];
        somapx = somapx + PX[i];
        somapy = somapy + PY[i];
        somapz = somapz + PZ[i];
        
    }
    
    //  Write tree.
    T1->Print(); // Print the screen (terminal) the information about the TTRee T
    T1->Write();
    
    cout << " sum px = "<< somapx << " sum py = "<< somapy << " sum pz = " << somapz << " sum E = "<< somaE << endl;
    
    
    // create one histogram
    TH1F *hist3 = new TH1F("hist3","Multiplicity CM",100,-10,10);

    
    // Energy Distribution
    TH1F *hist4 = new TH1F("hist4","Energy Distribution CM",100,-10,10);
    
    
    
    for(Int_t i=0; i<lNpts; i++) {
        
        hist3->Fill(eta[i]); // LAB 
        
        hist4->Fill(eta[i],E1[i]); // LAB
        
        if(eta[i] > 0){
            somaEp = somaEp + E1[i];
        }else{
            somaEn = somaEn + E1[i];
        }
        
    }

    
    cout << " sum E ( eta > 0) = " << somaEp << " GeV sum E (eta < 0) = " << somaEn << " GeV "<< endl;
    
    // Tcanvas hist3
    TCanvas *c3 = new TCanvas("c3","Histograms 3",600,400);
    c3->SetGrid(1,1);
    c3->SetLogx(0);
    c3->SetLogy(1);

    hist3->SetLineColor(kBlack);
    hist3->GetYaxis()->SetTitle("dN/d#eta");
    hist3->GetXaxis()->SetTitle("#eta ");
    hist3->SetMaximum(1000);
    hist3->Draw();
    
    // draw the legend
    TLegend *legend7a=new TLegend(0.6,1,0.88,0.85);
    legend7a->SetTextFont(72);
    legend7a->SetTextSize(0.04);
    legend7a->AddEntry(hist3,"CBJ Data","lpe");
    legend7a->Draw();

    // Tcanvas hist4
    TCanvas *c4 = new TCanvas("c4","Histograms 4 ",600,400);
    c4->SetGrid(1,1);
    c4->SetLogx(0);
    c4->SetLogy(1);
        
    hist4->SetLineColor(kBlack);
    hist4->GetYaxis()->SetTitle("dE/d#eta [GeV]");
    hist4->GetXaxis()->SetTitle("#eta ");
    hist4->Draw();
    
    // draw the legend
    TLegend *legend10a=new TLegend(0.6,1,0.88,0.85);
    legend10a->SetTextFont(72);
    legend10a->SetTextSize(0.04);
    legend10a->AddEntry(hist4,"CBJ Data","lpe");
    legend10a->Draw();
    
    }

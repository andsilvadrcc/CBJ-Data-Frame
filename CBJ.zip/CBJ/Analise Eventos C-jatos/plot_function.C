{
   TCanvas *c1 = new TCanvas("c1","Plot function",200,10,700,500);
 
   gStyle->SetOptStat(000000);
   TF1 *zfa1 = new TF1("zfa1","2.5*x^(0.25)",0,1000);

   zfa1->GetXaxis()->SetTitle("E_{0} [TeV]"); 
   zfa1->GetYaxis()->SetTitle("Multiplicidade de #pi");
   
   zfa1->Draw();
  
}

#include <ROOT/TDataFrame.hxx>
#include <TCanvas.h>
#include <TApplication.h>
#include <TLegend.h>


using namespace std;
using namespace ROOT::Experimental;
using namespace ROOT::Experimental::VecOps;


void Legend(){
    
    auto c1 = new TCanvas("c1","c1",600,500);
    gStyle->SetOptStat(0);
    auto h1 = new TH1F("h1","TLegend Example",200,-10,10);
    h1->FillRandom("gaus",30000);
    h1->SetFillColor(kGreen);
    h1->SetFillStyle(3003);
    h1->Draw();


    auto legend = new TLegend(0.1,0.7,0.48,0.9);
    legend->AddEntry(h1,"Histogram filled with random numbers","lep");
    legend->Draw();
   
}
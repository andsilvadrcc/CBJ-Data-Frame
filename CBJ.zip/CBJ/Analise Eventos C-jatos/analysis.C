
#include <ROOT/TDataFrame.hxx>
#include <TCanvas.h>
#include <TApplication.h>



using namespace std;
using namespace ROOT::Experimental;
using namespace ROOT::Experimental::VecOps;


    void analysis(){
        
        
        TDataFrame d("Particle","crmc_eposlhc_112108849_p_C_130000.root"); 
      
        
        // From EPOS LHC:
        auto hist1 = d.Histo1D({"hist1", "Multiplicity LAB", 100, -15, 15}, "px");
        
        // ******************************************************************************
        
        // Drawing
        auto c1 = new TCanvas("c1", "c1", 10, 10, 700, 500);
        c1->SetGrid(1,1);
        c1->SetLogx(0); // 0 == scale without Log, 1 == scale with Log.
        c1->SetLogy(1);
        
        hist1->GetYaxis()->SetTitle("dN/d#eta");
        hist1->GetXaxis()->SetTitle("#eta");
        hist1->DrawClone();
        
        // Draw the Legend 
        auto legend = new TLegend(0.1,0.7,0.48,0.9);
        legend->AddEntry("hist1","EPOS LHC","lep");
        legend->Draw();
        
        
    }
    
    int main(){
        TApplication app("app", nullptr, nullptr);
        analysis();
        app.Run();
    return 0;
    }
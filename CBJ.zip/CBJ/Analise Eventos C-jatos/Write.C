//
// Write.C
// ---------------------------------------------------------------------------
// Esta função escreve um arquivo txt de saída, com 5 colunas, x,y,E,eta,phi
// ---------------------------------------------------------------------------

#include <iostream>
#include <string>



//
void Write(Double_t *x1, Double_t *y1, Double_t *eta, Double_t *phi, Double_t *E1, Double_t *PT, int NLoops, const char *filename)
{
  FILE *fout;
  fout = fopen(filename,"a");
  for (int i=0;i<NLoops;i++){
    fprintf(fout,"%f \t  %f \t  %f \t %f \t %f \t %f \n", x1[i], y1[i], eta[i], phi[i], E1[i], PT[i]);
  }
  fclose(fout);  
  cout<<"As variaveis cinematicas (x,y,eta,phi,E,PT) foram salvas em um arquivo txt de nome: "<<filename<<endl;
}





    Double_t* ROTATION(Double_t x,Double_t y,Double_t alpha){
     
        Double_t *R = (Double_t*)calloc(2,sizeof(Double_t));    
            
            
            R[0] = x*cos(alpha)-y*sin(alpha); 
            R[1] = x*sin(alpha)+y*cos(alpha);

        //return pointer, well done!
        return R;
    }


    void teste(){

        Double_t x, y, alpha, *R;
        
        x = 1;
        y = 0;
        
        cout << "Before: x = " << x << " y = " << y << endl;
        
        //Angle of Rotation:
        alpha = TMath::Pi()/2;
        
        ROTATION(x,y,alpha);
        
        x = R[0];
        y = R[1];
    
    cout << " x' = " << x << " y' = " << y << endl;
  

    }
//
// read.C
//

using namespace std;

int read(const char , Double_t );

int read(const char *fileNameIn, Double_t *SOMAE)
{
  int i=0;
  ifstream fileIn(fileNameIn); //arquivo com os dados 
  if(!fileIn){
    cout<<"Could NOT Find File: "<<fileNameIn<<endl;
   return 0;  
}
  while ((fileIn >> SOMAE[i])) i++;
  if(i==0){ cout << "Nenhuma linha foi lida!!!"<<endl;} 
  else{cout << "READ file: " <<fileNameIn<<endl;}
return i;

}


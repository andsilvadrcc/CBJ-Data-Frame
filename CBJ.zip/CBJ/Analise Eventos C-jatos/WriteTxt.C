//
// WriteTxtPythia1.C
// ---------------------------------------------------------------------------
// Esta função escreve um arquivo txt de saída, com 3 colunas, phi, eta e energia.
// ---------------------------------------------------------------------------

void WriteTxt(Double_t *Px, Double_t *Py, Double_t *Pz, Double_t *vecE1,  int NLoops, const char *filename){

  FILE *fout;
  fout = fopen(filename,"w");
  for (int i=0;i<NLoops;i++){
    fprintf(fout,"particles.push_back( PseudoJet(%.6f, \t  %.6f, \t %.6f, \t %.6f) ); \n", Px[i], Py[i], Pz[i], vecE1[i]);
  }
  fclose(fout);  
  cout<<"Foi Salvo um arquivo txt de nome: "<<filename<<endl;
}

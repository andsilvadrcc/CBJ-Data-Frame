
#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TBrowser.h"
#include "TH1.h"
#include "TH1F.h"
#include "TH2.h"
#include "TRandom.h"
#include "TMath.h"
#include <iostream>
#include <string> 

#include "Write.C"
#include "Write_gama.C"
#include "readevento1.C"

    //***************************************************************
    //...Transformação de Lorentz (geral em todas as  direções)...
    Double_t* BOOST(Double_t bx,Double_t by,Double_t bz,Double_t px,Double_t py,Double_t pz,Double_t E1){
     
        //Array Elements of the matrix of Lorentz:
        Double_t A00, A11, A22, A33, A01, A02, A03, A12, A13, A23, beta;

        //Speed Parameter
        beta = sqrt(pow(bx,2)+pow(by,2)+pow(bz,2));
        
        // Lorentz Factor.
        Double_t gama = pow(1-(beta*beta),-0.5);
        
        //gama:
        A00 = gama;
        if(beta !=0){
            //Symmetrical elements of the matrix:
            A01 = -1*(bx*gama);
            A02 = -1*(by*gama);
            A03 = -1*(bz*gama);

            //Elements outside the diagonal:
            A12 = (gama-1)*((bx*by)/(beta*beta));
            A13 = (gama-1)*((bx*bz)/(beta*beta));
            A23 = (gama-1)*((by*bz)/(beta*beta));


            //Elements of the diagonal:
            A11 = (1+((gama-1)*((bx*bx)/(beta*beta))));
            A22 = (1+((gama-1)*((by*by)/(beta*beta))));
            A33 = (1+((gama-1)*((bz*bz)/(beta*beta))));
        }else{
            //Elements of the identity matrix:
            A11 = A22 = A33 = 1;
            A12 = A13 = A23 = 0;
            A01 = A02 = A03 = 0;
            
        }
        
        //Lorentz Transformation:
        Double_t P0 = (A00*E1) + (A01*px) + (A02*py) + (A03*pz);              
        Double_t P1 = (A01*E1) + (A11*px) + (A12*py) + (A13*pz);
        Double_t P2 = (A02*E1) + (A12*px) + (A22*py) + (A23*pz);
        Double_t P3 = (A03*E1) + (A13*px) + (A23*py) + (A33*pz);
        
        //cout<<" Matriz de Transformação "<<endl;
        //cout<<" "<<A00<<"  "<<A01<<"  "<<A02<<"  "<<A03<<"  "<<endl;
        //cout<<" "<<A01<<"  "<<A11<<"  "<<A12<<"  "<<A13<<"  "<<endl;
        //cout<<" "<<A02<<"  "<<A12<<"  "<<A22<<"  "<<A23<<"  "<<endl;
        //cout<<" "<<A03<<"  "<<A13<<"  "<<A23<<"  "<<A33<<"  "<<endl;
        
        Double_t *vector = (Double_t*)malloc(4*sizeof(Double_t));  

        //return the 4-vector (E,px,py,pz) = (P0,P1,P2,P3).
        vector[0] = P0;
        vector[1] = P1;
        vector[2] = P2;
        vector[3] = P3;

        //return pointer
        return vector;
    }

    // ***********************************************************

    

    void Variaveis_Cinematicas(int lNpts, Double_t *x, Double_t *y, Double_t *E1, Double_t FatorC, Double_t AnguloZenitalPPI ){
    
    //Precision:
    cout<<fixed;
    cout<<setprecision(10);
        
    #define N 2000
    Double_t phi[N], theta[N], eta[N], PT[N], aux1=0,aux2=0, px[N], py[N], pz[N], E1T[N], pxT[N], pyT[N], pzT[N], GAMA[0], SOMAE[0];
    Double_t somaE=0, somapx=0,somaEta=0, somapy=0, somapz=0, bx, by, bz, beta, xcpe, ycpe, h, H = 168.5,somaEtaM=0, gama; //cm;
    
    // 82 eventos C-jatos.
    // altura H = 157 cm + 11.5 cm (metade do alvo de Carbono).

    Double_t* v; //BOOST
    
    h = H/cos(AnguloZenitalPPI);
    
    for(long i=0; i<lNpts; i++){  

        E1[i] = 1000*E1[i]; //GeV
        x[i] = FatorC*x[i]; //cm 
        y[i] = FatorC*y[i]; //cm
        
        somaE += E1[i]; // Energia total do evento.
        aux1 += x[i]*E1[i];
        aux2 += y[i]*E1[i];
        

    }
    
    //Posição do Centro Ponderado de Energia - CPE.
    xcpe = aux1/somaE;
    ycpe = aux2/somaE;
    

    for(long i=0; i<lNpts; i++){ 

    //As coordenadas no referencial do Centro Ponderado de Energia - CPE.
    x[i] = x[i] - xcpe;
    y[i] = y[i] - ycpe;
    
    // conversão para cm e para o PPI:
    //x[i] = x[i]*cos(AnguloZenitalPPI); 
    //y[i] = y[i]*cos(AnguloZenitalPPI);

    //Ângulo Theta em radiano.
    theta[i]= atan(sqrt(pow(x[i],2)+pow(y[i],2))/h); 
    
    //Pseudorapidity LAB.
    eta[i] = -1*log(tan(theta[i]/2));
    
    
    //soma eta:
    somaEta = somaEta + eta[i];

    //Ângulo Phi
    phi[i] = atan2(y[i],x[i]);
    
    

    //pt e px, py e pz em GeV
    PT[i] = E1[i]*sin(theta[i]); 
    px[i] = PT[i]*cos(phi[i]);
    py[i] = PT[i]*sin(phi[i]);
    pz[i] = E1[i]*cos(theta[i]);

    //Soma de px, py e pz:
    somapx += px[i];
    somapy += py[i];
    somapz += pz[i];

    }
    
    //Variáveis Cinemáticas no LAB:
    Write(x,y,eta,phi,E1,PT,lNpts,"Dados_de_todos_Eventos_LAB.txt");
    
    somaEtaM = somaEta/lNpts;
    
    cout << " sum pz = " << somapz<< " sum E " << somaE << endl;
    
    
    //Parâmetro da velocidade bx, by, bz:
    bx = somapx/(somaE); 
    by = somapy/(somaE); 
    bz = somapz/(somaE); 
    beta = TMath::Sqrt(pow(bx,2)+pow(by,2)+pow(bz,2));   

    gama = pow(1-pow(beta,2),-0.5);
    
    GAMA[0] = gama;
    
    Write_gama(GAMA,1,"Lorentz_factors.txt");
    
    SOMAE[0] = somaE;
    
    Write_gama(SOMAE,1,"Energy_C-jets_Events.txt");
    
    
    
    cout << "beta = " << beta << " gama = " << gama << " eta medio = "<< somaEtaM << endl;
    

    for(long i=0; i<lNpts; i++){  
        
        v = BOOST(bx,by,bz,px[i],py[i],pz[i],E1[i]);  
        E1T[i] = v[0]; 
        pxT[i] = v[1]; 
        pyT[i] = v[2];           
        pzT[i] = v[3];                  
        
        free(v);  
    
        if(eta[i] > somaEtaM){
            cout <<"forward: eta = " << eta[i] << " phi = " << phi[i]<< "E = " << E1[i] << endl;
        }else{
            cout <<"backward: eta = " << eta[i] << " phi = " << phi[i] << endl;
        }
        
        // Theta CM:
        cout << "pt = " << PT[i] << " pz* = " << pzT[i] << endl;
        theta[i] = atan2(PT[i],pzT[i]);

        //Pseudorapidity CM:
        eta[i] = -1*log(tan(theta[i]/2));


        
    }   
    //Variáveis Cinemáticas no CM:
    Write(x,y,eta,phi,E1T,PT,lNpts,"Dados_de_todos_Eventos_CM.txt");
        

    
    
    }
    

    //Let's begin the function here!

    void Todos_EventosCBJ(){

    #define N 2000

    cout<<fixed;
    cout<<setprecision(6);

    //definição das variáveis.
    Double_t x[N], y[N], E1[N], FatorC, AnguloZenitalPPI;
    int lNpts;
    
    //Evento.                                                                        
    lNpts = readevento1("evento1517.txt",x,y,E1);
    
    
    //Parâmetros do Evento:
    FatorC =0.0073; 
    AnguloZenitalPPI = atan(0.1860); 

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);

     
    // ******************************************************************************
    //Evento.  
    lNpts = readevento1("evento1528.txt",x,y,E1);
    
    //Parâmetros do Evento:
    FatorC = 0.0061; 
    AnguloZenitalPPI = atan(0.5700);  
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);

    
    // ******************************************************************************
    
    //Evento.
    lNpts = readevento1("evento1543.txt",x,y,E1);
    FatorC = 0.0097; 
    AnguloZenitalPPI = atan(0.3400);  
      
    
    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    //Evento.
    lNpts= readevento1("evento1547.txt",x,y,E1); 
    FatorC = 0.0018; 
    AnguloZenitalPPI = atan(0.3900);
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    //Evento.
    lNpts= readevento1("evento1567.txt",x,y,E1); 
    FatorC = 0.0117;  
    AnguloZenitalPPI = atan(0.1850); 
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento156725.txt",x,y,E1); 
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.9310);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1576.txt",x,y,E1); 
    FatorC = 0.006; 
    AnguloZenitalPPI = atan(0.3000);
       

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1577.txt",x,y,E1); 
    FatorC = 0.0061; 
    AnguloZenitalPPI = atan(0.0000);
      

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1584.txt",x,y,E1); 
    FatorC = 0.012; 
    AnguloZenitalPPI = atan(0.3600); 
     

    
    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento1597.txt",x,y,E1); 
    FatorC = 0.0044; 
    AnguloZenitalPPI = atan(0.8020);  
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento15102.txt",x,y,E1); 
    FatorC = 0.008; 
    AnguloZenitalPPI = atan(0.5400);
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento15105.txt",x,y,E1); 
    FatorC = 0.0176; 
    AnguloZenitalPPI = atan(0.0000); 
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento15115.txt",x,y,E1);
    FatorC = 0.016; 
    AnguloZenitalPPI = atan(0.5010);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento15150.txt",x,y,E1);
    FatorC = 0.0088; 
    AnguloZenitalPPI = atan(0.7240);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento15156.txt",x,y,E1); 
    FatorC = 0.004;  
    AnguloZenitalPPI = atan(0.0000); 
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento15159.txt",x,y,E1);
    FatorC = 0.004;  
    AnguloZenitalPPI = atan(0.0000); 

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento151614.txt",x,y,E1);
    FatorC = 0.0044; 
    AnguloZenitalPPI = atan(0.8820);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento1680.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.6900); 
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento1685.txt",x,y,E1);
    FatorC = 0.0035; 
    AnguloZenitalPPI = atan(0.1100);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento1686.txt",x,y,E1);
    FatorC = 0.0035; 
    AnguloZenitalPPI = atan(0.7420);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento1691.txt",x,y,E1);
    FatorC = 0.0142; 
    AnguloZenitalPPI = atan(0.4320);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento1696.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.1500);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento16101.txt",x,y,E1);
    FatorC = 0.0034; 
    AnguloZenitalPPI = atan(0.1000);
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento16105.txt",x,y,E1);
    FatorC = 0.0142; 
    AnguloZenitalPPI = atan(0.4110);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento17192.txt",x,y,E1);
    FatorC = 0.003; 
    AnguloZenitalPPI = atan(0.5960);
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento1769.txt",x,y,E1);
    FatorC = 0.0033; 
    AnguloZenitalPPI = atan(0.0000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento17791.txt",x,y,E1);
    FatorC = 0.0033; 
    AnguloZenitalPPI = atan(0.6510);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento17792.txt",x,y,E1);
    FatorC = 0.0033; 
    AnguloZenitalPPI = atan(0.2590); 

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento17841.txt",x,y,E1);
    FatorC = 0.0072;  
    AnguloZenitalPPI = atan(0.2500);
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento17842.txt",x,y,E1);
    FatorC = 0.0074;  
    AnguloZenitalPPI = atan(0.9490);
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento1786.txt",x,y,E1);
    FatorC = 0.0072;   
    AnguloZenitalPPI = atan(0.4350);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento1789.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.9500);
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento1790.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.1670);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento17961.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.7500);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17962.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.1000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento171022.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.3700);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento171024.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.4620);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17104.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.2500);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17105.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.3000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17115.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.4290);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17122.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.6150);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17124.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.8700);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17130.txt",x,y,E1);
    FatorC = 0.01;
    AnguloZenitalPPI = atan(0.1400);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17132.txt",x,y,E1);
    FatorC = 0.0036; 
    AnguloZenitalPPI = atan(0.2080);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento171351.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.4900);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento171354.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.0000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17136.txt",x,y,E1);
    FatorC = 0.0072;  
    AnguloZenitalPPI = atan(0.2270);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento171382.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.3830);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento171388.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.2000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17140.txt",x,y,E1);
    FatorC = 0.0072;  
    AnguloZenitalPPI = atan(0.2220);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17148.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.5560);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17150.txt",x,y,E1);
    FatorC = 0.0036;  
    AnguloZenitalPPI = atan(0.6450);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17159.txt",x,y,E1);
    FatorC = 0.0072;  
    AnguloZenitalPPI = atan(0.5830);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento17164.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.3330);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1821.txt",x,y,E1);
    FatorC = 0.0036; 
    AnguloZenitalPPI = atan(0.0000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1824.txt",x,y,E1);
    FatorC = 0.0066; 
    AnguloZenitalPPI = atan(0.9090);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1828.txt",x,y,E1);
    FatorC = 0.0033; 
    AnguloZenitalPPI = atan(1.1700);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1830.txt",x,y,E1);
    FatorC = 0.0036;  
    AnguloZenitalPPI = atan(0.5500);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1832.txt",x,y,E1);
    FatorC = 0.0036; 
    AnguloZenitalPPI = atan(0.5500);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1847.txt",x,y,E1);
    FatorC = 0.0066; 
    AnguloZenitalPPI = atan(1.0000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1849.txt",x,y,E1);
    FatorC = 0.0066; 
    AnguloZenitalPPI = atan(0.9040); 
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1869.txt",x,y,E1);
    FatorC = 0.003;  
    AnguloZenitalPPI = atan(0.9040);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento187330.txt",x,y,E1);
    FatorC = 0.009; 
    AnguloZenitalPPI = atan(0.0000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento187650.txt",x,y,E1);
    FatorC = 0.009; 
    AnguloZenitalPPI = atan(0.0000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1892.txt",x,y,E1);
    FatorC = 0.0072;
    AnguloZenitalPPI = atan(0.17);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento1893.txt",x,y,E1);
    FatorC = 0.0072;
    AnguloZenitalPPI = atan(0.2000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    lNpts= readevento1("evento18110.txt",x,y,E1);
    FatorC = 0.01;  
    AnguloZenitalPPI = atan(0.3100);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento18139.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.5150);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento18145.txt",x,y,E1);
    FatorC = 0.005;  
    AnguloZenitalPPI = atan(0.6670);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento18149.txt",x,y,E1);
    FatorC = 0.0023; 
    AnguloZenitalPPI = atan(0.6670);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento19100.txt",x,y,E1);
    FatorC = 0.005;  
    AnguloZenitalPPI = atan(0.0000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento19105.txt",x,y,E1);
    FatorC = 0.0144; 
    AnguloZenitalPPI = atan(0.1500);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento19107.txt",x,y,E1);
    FatorC = 0.005; 
    AnguloZenitalPPI = atan(0.3600);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento19108.txt",x,y,E1);
    FatorC = 0.0072;  
    AnguloZenitalPPI = atan(0.5000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento19115.txt",x,y,E1);
    FatorC = 0.01;  
    AnguloZenitalPPI = atan(0.5000);
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento191214.txt",x,y,E1);
    FatorC = 0.0072; 
    AnguloZenitalPPI = atan(0.0000);
     

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento191215.txt",x,y,E1);
    FatorC = 0.005; 
    AnguloZenitalPPI = atan(0.6000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento19127.txt",x,y,E1);
    FatorC = 0.005;  
    AnguloZenitalPPI = atan(0.5000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento19129.txt",x,y,E1);
    FatorC = 0.0064; 
    AnguloZenitalPPI = atan(0.8400);
    
    
    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    
    lNpts= readevento1("evento191361.txt",x,y,E1);
    FatorC = 0.0064; 
    AnguloZenitalPPI = atan(0.0000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento191362.txt",x,y,E1);
    FatorC = 0.0025; 
    AnguloZenitalPPI = atan(0.3000);
    

    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
    lNpts= readevento1("evento19138.txt",x,y,E1);
    FatorC = 0.0025; 
    AnguloZenitalPPI = atan(0.000);
    


    Variaveis_Cinematicas(lNpts,x,y,E1,FatorC,AnguloZenitalPPI);
    
    // ******************************************************************************
    
  
    }
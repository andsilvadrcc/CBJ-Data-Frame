
#include <ROOT/TDataFrame.hxx>
#include <TCanvas.h>
#include <TApplication.h>
#include <math.h>


using namespace std;
using namespace ROOT::Experimental;
using namespace ROOT::Experimental::VecOps;


    void EPOS_LHC_CBJ1(){
        
        
        
        // ******************************************************************************
        //                      Multiplicity LAB: CBJ Data/EPOS LHC
        
        gStyle->SetOptStat(111); // histogram statistics box can be selected
        
        
        
        // File from EPOS LHC proton-proton collisions in the LAB frame Energy: 130 TeV.
        //TDataFrame d("Particle","crmc_eposlhc_63906640_p_p_130000.root"); 
        
        // File from EPOS LHC proton-Carbon collisions in the LAB frame Energy: 130 TeV.
        TDataFrame d("Particle","crmc_eposlhc_130842692_p_C_130000.root"); 
        
        // File from EPOS LHC proton-Lead collisions in the LAB frame Energy: 130 TeV.
        ///TDataFrame d("Particle","crmc_eposlhc_702489137_p_Pb_130000.root");
        
        // File from EPOS LHC pion-Carbon collisions in the LAB frame Energy: 130 TeV.
        //TDataFrame d("Particle","crmc_eposlhc_169365978_pi_C_130000.root"); 
        
        // File from EPOS LHC pion-Lead collisions in the LAB frame Energy: 130 TeV.
        //TDataFrame d("Particle","crmc_eposlhc_392248601_pi_Pb_130000.root"); 
        
        
        
        //CBJ Data in the LAB frame
        TDataFrame d1("T","Dados_de_todos_Eventos_LAB.root");
        
        //CBJ Data in the CM frame
        TDataFrame d2("T1","Dados_de_todos_Eventos_CM.root");
        
        // ******************************************************************************
        
        auto c1 = new TCanvas("c1", "c1", 10, 10, 3000, 3000);
        c1->Divide(2,2);
        
        
        // One TCanvas.
        auto hs = new THStack("hs","Histograms");
        
        // Histograms: Multiplicity in the LAB Frame:
        
        // From CBJ Data:
        auto hist1 = d1.Histo1D({"hist1", "Multiplicity LAB", 100, 0, 20},"Eta");
        auto hist1_ptr = (TH1D*)&hist1.GetValue();
        hs->Add(hist1_ptr);
        
        // precision:
        cout<<fixed;
        cout<<setprecision(10);

        
        cout << " Multiplicity average/hist CBJ = " << hist1->GetMean() << endl;
        
        // TVec 
        using doubles = TVec<double>;
        using ints = TVec<int>;

        // Calculate rapidity and pass by a filter (Energy Cut)
        auto RapidityCalc = [](doubles Es, doubles pzs, ints pdgids) {
            auto all_RapidityCalc = 0.5*log((Es+pzs)/(Es-pzs));
            auto good_RapidityCalc = all_RapidityCalc[Es > 500. && pdgids == 22];
        return good_RapidityCalc;
        };
        
        auto dd = d.Define("y", RapidityCalc, {"E", "pz", "pdgid"});
        
        // From EPOS LHC:
        auto hist2 = dd.Histo1D({"hist2", "Multiplicity LAB", 100, 0, 20}, "y");
        auto hist2_ptr = (TH1D*)&hist2.GetValue();
        hs->Add(hist2_ptr);
        
        double etaMedia = hist2->GetMean();
        
        cout << " Multiplicity average/hist EPOS LHC = " << etaMedia << endl;
        
        double beta = (pow(exp(1),2*etaMedia)-1)/(pow(exp(1),2*etaMedia)+1);
        
        double gama = pow(1-pow(beta,2),-0.5);
        
        cout << " beta " << beta << "  gama = " << gama << endl;
        
        // Chi2 Test ...
        Double_t res[100];
        hist1->Chi2Test(hist2_ptr,"UW P",res);
        
        
        // ******************************************************************************
        
        // The histograms:
        c1->cd(1);
        c1->cd(1)->SetGridx();    // Horizontal grid
        c1->cd(1)->SetGridy();    // Vertical grid
        hs->Draw();
        c1->cd(1)->SetLogy(1);
        
        //normalize histogram
        hist1->Scale(1/(hist1->Integral()));
        
        //normalize histogram
        hist2->Scale(1/(hist2->Integral()));
        
        hist1->GetYaxis()->SetTitle("dN/d#eta");
        hist1->GetXaxis()->SetTitle("#eta");
        hist1->GetXaxis()->CenterTitle();
        hist1->GetYaxis()->CenterTitle();
        
        hist1->GetYaxis()->SetTitleSize(30);
        hist1->GetYaxis()->SetTitleFont(43);
        hist1->GetYaxis()->SetTitleOffset(1.4);
        hist1->GetYaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
        hist1->GetYaxis()->SetLabelSize(20);
        
        hist1->GetXaxis()->SetTitleSize(30);
        hist1->GetXaxis()->SetTitleFont(43);
        hist1->GetXaxis()->SetTitleOffset(1.5);
        hist1->GetXaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
        hist1->GetXaxis()->SetLabelSize(20);
        
        hist1->SetMaximum(1);
        hist1->SetFillStyle(1);
        hist1->SetMarkerStyle(8);
        hist1->SetMarkerSize(1);
        hist1->SetMarkerColor(1);
        hist1->DrawClone("phistE1");
        
        hist2->SetLineColor(kRed);
        hist2->SetFillStyle(3001);
        hist2->SetLineWidth(2);
        hist2->SetLineStyle(1);
        hist2->DrawClone("histsame");
        
        // Draw the Legend 
        auto legend = new TLegend(0.7,0.7,0.9,0.8);
        legend->AddEntry("hist1","CBJ Data","lep");
        legend->Draw();
        
        // Draw the Legend 
        auto legend1 = new TLegend(0.1,0.8,0.5,0.9);
        legend1->AddEntry("hist2","EPOS LHC (pC): E_{cut}","lep");
        legend1->Draw();
        
        TLegendEntry *header1 = (TLegendEntry*)legend1->GetListOfPrimitives()->First();
        header1->SetTextSize(.06);
        
        
        
        // ******************************************************************************
        //                      Energy Distribuition LAB: CBJ Data/EPOS LHC
        
        // TVec 
        using doubles = TVec<double>;
        using ints = TVec<int>;
        
        // From CBJ Data:
        auto hist3 = d1.Histo1D({"hist3", "Energy Distribution LAB", 100, 0, 20}, "Eta", "e");
        auto hist3_ptr = (TH1D*)&hist3.GetValue();
        hs->Add(hist3_ptr);
        
        cout << " Energy: average/hist CBJ = " << hist3->GetMean() << endl;
        
        // Calculate rapidity and pass by a filter (Energy Cut)
        auto RapCalc = [](doubles Es, doubles pzs, ints pdgids) {
            auto all_RapCalc  = 0.5*log((Es+pzs)/(Es-pzs));
            auto good_RapCalc = all_RapCalc[Es > 500. && pdgids == 22];
            return good_RapCalc;
        };
        
        
        auto dd1 = d.Define("rap", RapCalc, {"E", "pz", "pdgid"}).Define("good_E", "E[E>500. && pdgid == 22]");
        auto hist4 = dd1.Histo1D({"hist4", "Energy Distribution LAB", 100, 0, 20}, "rap", "good_E");
        auto hist4_ptr = (TH1D*)&hist4.GetValue();
        hs->Add(hist4_ptr);
        
        cout << " Energy: average/hist EPOS LHC = " << hist4->GetMean() << endl;
    
        c1->cd(2);
        c1->cd(2)->SetGridx();    // Horizontal grid
        c1->cd(2)->SetGridy();    // Vertical grid
        hs->Draw();
        c1->cd(2)->SetLogy(1);
        
        
        //normalize histogram
        hist3->Scale(1/(hist3->Integral()));
        
        //normalize histogram
        hist4->Scale(1/(hist4->Integral()));
        
        hist3->GetYaxis()->SetTitle("dE/d#eta");
        hist3->GetXaxis()->SetTitle("#eta");
        hist3->GetXaxis()->CenterTitle();
        hist3->GetYaxis()->CenterTitle();
        
        hist3->GetYaxis()->SetTitleSize(30);
        hist3->GetYaxis()->SetTitleFont(43);
        hist3->GetYaxis()->SetTitleOffset(1.4);
        hist3->GetYaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
        hist3->GetYaxis()->SetLabelSize(20);

        hist3->GetXaxis()->SetTitleSize(30);
        hist3->GetXaxis()->SetTitleFont(43);
        hist3->GetXaxis()->SetTitleOffset(1.5);
        hist3->GetXaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
        hist3->GetXaxis()->SetLabelSize(20);
    
        hist3->SetMaximum(1);
        hist3->SetFillStyle(1);
        hist3->SetMarkerStyle(8);
        hist3->SetMarkerSize(1);
        hist3->SetMarkerColor(1);
        hist3->DrawClone("phistE1");
        
        hist4->SetLineColor(kRed);
        hist4->SetFillStyle(3001);
        hist4->SetLineWidth(2);
        hist4->SetLineStyle(1);
        hist4->DrawClone("histsame");
        
        // Draw the Legend 
        auto legend2 = new TLegend(0.7,0.7,0.9,0.8);
        legend2->AddEntry("hist3","CBJ Data","lep");
        legend2->Draw();
        
        // Draw the Legend 
        auto legend3 = new TLegend(0.1,0.8,0.5,0.9);
        legend3->AddEntry("hist4","EPOS LHC (pC): E_{cut}","lep");
        legend3->Draw();
        
        TLegendEntry *header3 = (TLegendEntry*)legend3->GetListOfPrimitives()->First();
        header3->SetTextSize(.06);
        
    
        // ******************************************************************************
        // ******************************************************************************
        
        // TVec 
        using doubles = TVec<double>;
        using ints = TVec<int>;

        
        // ******************************************************************************
        //                      Multiplicity CM: CBJ Data/EPOS LHC
        
        // Histograms: Multiplicity in the LAB Frame:
    
        // From CBJ Data:
        auto hist5 = d2.Histo1D({"hist5", "Multiplicity CM", 100, -10, 10},"Eta");
        auto hist5_ptr = (TH1D*)&hist5.GetValue();
        hs->Add(hist5_ptr);
        
        // Calculate rapidity and pass by a filter (Energy Cut)
        auto RapidityCal = [&beta](doubles Es, doubles pzs, ints pdgids) {
            auto all_RapidityCal = 0.5*log((Es +pzs)/(Es - pzs)) - 0.5*log((1+beta)/(1-beta));
            auto good_RapidityCal = all_RapidityCal[Es > 500. && pdgids == 22];
        return good_RapidityCal;
        };
        
        auto dd3 = d.Define("rap1", RapidityCal, {"E", "pz", "pdgid"});
        
        // From EPOS LHC:
        auto hist6 = dd3.Histo1D({"hist6", "Multiplicity CM", 100, -10, 10}, "rap1");
        auto hist6_ptr = (TH1D*)&hist6.GetValue();
        hs->Add(hist6_ptr);
        // ******************************************************************************
        
        c1->cd(3);
        c1->cd(3)->SetGridx();    // Horizontal grid
        c1->cd(3)->SetGridy();    // Vertical grid
        hs->Draw();
        c1->cd(3)->SetLogy(1);
        
        //normalize histogram
        hist5->Scale(1/(hist5->Integral()));
        
        //normalize histogram
        hist6->Scale(1/(hist6->Integral()));
        
        hist5->GetYaxis()->SetTitle("dN/d#eta");
        hist5->GetXaxis()->SetTitle("#eta");
        hist5->GetXaxis()->CenterTitle();
        hist5->GetYaxis()->CenterTitle();
        
        hist5->GetYaxis()->SetTitleSize(30);
        hist5->GetYaxis()->SetTitleFont(43);
        hist5->GetYaxis()->SetTitleOffset(1.4);
        hist5->GetYaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
        hist5->GetYaxis()->SetLabelSize(20);

        hist5->GetXaxis()->SetTitleSize(30);
        hist5->GetXaxis()->SetTitleFont(43);
        hist5->GetXaxis()->SetTitleOffset(1.5);
        hist5->GetXaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
        hist5->GetXaxis()->SetLabelSize(20);
        
        hist5->SetMaximum(1);
        hist5->SetFillStyle(1);
        hist5->SetMarkerStyle(8);
        hist5->SetMarkerSize(1);
        hist5->SetMarkerColor(1);
        hist5->DrawClone("phistE1");
        
        hist6->SetLineColor(kRed);
        hist6->SetFillStyle(3001);
        hist6->SetLineWidth(2);
        hist6->SetLineStyle(1);
        hist6->DrawClone("histsame");
        
        // Draw the Legend 
        auto legend4 = new TLegend(0.7,0.7,0.9,0.8);
        legend4->AddEntry("hist5","CBJ Data","lep");
        legend4->Draw();
        
        // Draw the Legend 
        auto legend5 = new TLegend(0.1,0.8,0.5,0.9);
        legend5->AddEntry("hist6","EPOS LHC (pC): E_{cut}","lep");
        legend5->Draw();
        
        TLegendEntry *header5 = (TLegendEntry*)legend5->GetListOfPrimitives()->First();
        header5->SetTextSize(.06);
        
        
        
        // ******************************************************************************
        //                      Energy Distribuition CM: CBJ Data/EPOS LHC
        
        // From CBJ Data:
        auto hist7 = d2.Histo1D({"hist7", "Energy Distribution CM", 100, -10, 10}, "Eta", "e");
        auto hist7_ptr = (TH1D*)&hist7.GetValue();
        hs->Add(hist7_ptr);
        
        // Calculate rapidity and pass by a filter (Energy Cut)
        auto RapCal = [&beta, &gama](doubles Es, doubles pzs) {
            auto all_RapCal  = 0.5*log((Es+pzs)/(Es-pzs)) - 0.5*log((1+beta)/(1-beta));
            auto good_RapCal = all_RapCal[Es > 500.];
            return good_RapCal;
        };
        
        auto EnergyCM = [&beta, &gama](doubles Es, doubles pzs) {
            auto all_Energy  = gama*Es - beta*gama*pzs;
            auto good_Energy = all_Energy[Es > 500.];
            return good_Energy;
        };
        
        
        auto ddd1 = d.Define("rap2", RapCal, {"E", "pz"}).Define("good_E2", EnergyCM,{"E", "pz"});
        auto hist8 = ddd1.Histo1D({"hist8", "Energy Distribution CM", 100, -10, 10}, "rap2", "good_E2");
        auto hist8_ptr = (TH1D*)&hist8.GetValue();
        hs->Add(hist8_ptr);
        
        c1->cd(4);
        c1->cd(4)->SetGridx();    // Horizontal grid
        c1->cd(4)->SetGridy();    // Vertical grid
        hs->Draw();
        c1->cd(4)->SetLogy(1);
        
        //normalize histogram
        hist7->Scale(1/(hist7->Integral()));

        //normalize histogram
        hist8->Scale(1/(hist8->Integral()));
        
        hist7->GetYaxis()->SetTitle("dE/d#eta");
        hist7->GetXaxis()->SetTitle("#eta");
        hist7->GetXaxis()->CenterTitle();
        hist7->GetYaxis()->CenterTitle();
        
        hist7->GetYaxis()->SetTitleSize(30);
        hist7->GetYaxis()->SetTitleFont(43);
        hist7->GetYaxis()->SetTitleOffset(1.4);
        hist7->GetYaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
        hist7->GetYaxis()->SetLabelSize(20);

        hist7->GetXaxis()->SetTitleSize(30);
        hist7->GetXaxis()->SetTitleFont(43);
        hist7->GetXaxis()->SetTitleOffset(1.5);
        hist7->GetXaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
        hist7->GetXaxis()->SetLabelSize(20);
    
        hist7->SetMaximum(1);
        hist7->SetFillStyle(1);
        hist7->SetMarkerStyle(8);
        hist7->SetMarkerSize(1);
        hist7->SetMarkerColor(1);
        hist7->DrawClone("phistE1");
        
        hist8->SetLineColor(kRed);
        hist8->SetFillStyle(3001);
        hist8->SetLineWidth(2);
        hist8->SetLineStyle(1);
        hist8->DrawClone("histsame");
        
        // Draw the Legend 
        auto legend6 = new TLegend(0.7,0.7,0.9,0.8);
        legend6->AddEntry("hist7","CBJ Data","lep");
        legend6->Draw();
        
        // Draw the Legend 
        auto legend7 = new TLegend(0.1,0.8,0.5,0.9);
        legend7->AddEntry("hist8","EPOS LHC (pC): E_{cut}","lep");
        legend7->Draw();
        
        TLegendEntry *header7 = (TLegendEntry*)legend7->GetListOfPrimitives()->First();
        header7->SetTextSize(.06);
        
        
        // Save in .png
        c1->SaveAs("Graph_EQD/EPOS_LHC/EPOS_pp.png");
        
        //Well Done! Great Job.
        
        
    }
    
    int main(){
        TApplication app("app", nullptr, nullptr);
        EPOS_LHC_CBJ1();
        app.Run();
    return 0;
    }


#include <ROOT/TDataFrame.hxx>
#include <TCanvas.h>
#include <TApplication.h>



using namespace std;
using namespace ROOT::Experimental;
using namespace ROOT::Experimental::VecOps;


    void EPOS_LHC_CBJ(){
        
    
        
        // ******************************************************************************
        //                      Multiplicity LAB: CBJ Data/EPOS LHC
        
        // File from EPOS LHC proton-Carbon collisions in the LAB frame Energy: 130 TeV.
        TDataFrame d("Particle","crmc_eposlhc_112108849_p_C_130000.root"); 
      
        //CBJ Data in the LAB frame
        TDataFrame d1("T","Dados_de_todos_Eventos_LAB.root");
        
        //CBJ Data in the CM frame
        TDataFrame d2("T1","Dados_de_todos_Eventos_CM.root");
        
        // ******************************************************************************
        
        // Histograms: Multiplicity in the LAB Frame:
    
        // From CBJ Data:
        auto hist1 = d1.Histo1D({"hist1", "Multiplicity LAB", 100, -20, 20},"Eta");
        
        // TVec 
        using doubles = TVec<double>;
        using ints = TVec<int>;

        // Calculate rapidity and pass by a filter (Energy Cut)
        auto RapidityCalc = [](doubles Es, doubles pzs, ints pdgids) {
            auto all_RapidityCalc = 0.5*log((Es+pzs)/(Es-pzs));
            auto good_RapidityCalc = all_RapidityCalc[Es > 200. && pdgids == 22];
        return good_RapidityCalc;
        };
        
        auto dd = d.Define("y", RapidityCalc, {"E", "pz", "pdgid"});
        
        // From EPOS LHC:
        auto hist2 = dd.Histo1D({"hist2", "Multiplicity LAB", 100, -15, 15}, "y");
        
        // ******************************************************************************
        
        // Drawing
        auto c1 = new TCanvas("c1", "c1", 10, 10, 700, 500);
        c1->SetGrid(1,1);
        c1->SetLogx(0); // 0 == scale without Log, 1 == scale with Log.
        c1->SetLogy(1);
        
        //normalize histogram
        hist1->Scale(1/(hist1->Integral()));
        
        //normalize histogram
        hist2->Scale(1/(hist2->Integral()));
        
        hist1->GetYaxis()->SetTitle("dN/d#eta");
        hist1->GetXaxis()->SetTitle("#eta");
        hist1->SetMaximum(1);
        hist1->SetLineColor(kBlack);
        hist1->DrawClone();
        hist2->SetLineColor(kRed);
        hist2->DrawClone("same");
        
        // Draw the Legend 
        auto legend = new TLegend(0.1,0.7,0.48,0.9);
        legend->AddEntry("hist1","CBJ Data","lep");
        legend->Draw();
        
        // Draw the Legend 
        auto legend1 = new TLegend(0.1,0.7,0.48,0.9);
        legend1->AddEntry("hist2","PYTHIA 8 softQCD with E_{cut}","lep");
        legend1->Draw();
        
        
        // ******************************************************************************
        //                      Energy Distribuition LAB: CBJ Data/EPOS LHC
        
        // TVec 
        using doubles = TVec<double>;
        using ints = TVec<int>;
        
        // From CBJ Data:
        auto hist3 = d1.Histo1D({"hist3", "Energy distribution", 100, -20, 20}, "Eta", "e");
        
        
        // Calculate rapidity and pass by a filter (Energy Cut)
        auto RapCalc = [](doubles Es, doubles pzs) {
            auto all_RapCalc  = 0.5*log((Es+pzs)/(Es-pzs));
            auto good_RapCalc = all_RapCalc[Es > 500.];
            return good_RapCalc;
        };
        
        
        auto dd1 = d.Define("rap", RapCalc, {"E", "pz"}).Define("good_E", "E[E>500]");
        auto hist4 = dd1.Histo1D({"hist4", "Energy distribution", 100, -20, 20}, "rap", "good_E");
    
        
        // Drawing
        auto c2 = new TCanvas("c2", "c2", 10, 10, 700, 500);
        c2->SetGrid(1,1);
        c2->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
        c2->SetLogy(1);
        
        //normalize histogram
        hist3->Scale(1/(hist3->Integral()));
        
        //normalize histogram
        hist4->Scale(1/(hist4->Integral()));
        
        hist3->GetYaxis()->SetTitle("dE/d#eta [GeV]");
        hist3->GetXaxis()->SetTitle("#eta");
        hist3->SetMaximum(1);
        hist3->SetLineColor(kBlack);
        hist3->DrawClone();
        
        hist4->SetLineColor(kRed);
        hist4->DrawClone("same");
        
        // Draw the Legend 
        auto legend2 = new TLegend(0.1,0.7,0.48,0.9);
        legend2->AddEntry("hist3","CBJ Data","lep");
        legend2->Draw();
        
        // Draw the Legend 
        auto legend3 = new TLegend(0.1,0.7,0.48,0.9);
        legend3->AddEntry("hist4","PYTHIA 8 softQCD with E_{cut}","lep");
        legend3->Draw();
        
        
        // ******************************************************************************
        // ******************************************************************************
        
        // TVec 
        using doubles = TVec<double>;
        using ints = TVec<int>;
        
        // File from EPOS LHC proton-Carbon collisions in the CM frame Energy: 1.7 TeV.
        TDataFrame TDF("Particle","crmc_eposlhc_142721946_p_C_852.root");
        
        
        // ******************************************************************************
        //                      Multiplicity CM: CBJ Data/EPOS LHC
        
        // Histograms: Multiplicity in the LAB Frame:
    
        // From CBJ Data:
        auto hist5 = d2.Histo1D({"hist5", "Multiplicity CM", 100, -20, 20},"Eta");
    

        // Calculate rapidity and pass by a filter (Energy Cut)
        auto RapidityCal = [](doubles Es, doubles pzs, ints pdgids) {
            auto all_RapidityCal = 0.5*log((Es+pzs)/(Es-pzs));
            auto good_RapidityCal = all_RapidityCal[Es > 0 && pdgids == 22];
        return good_RapidityCal;
        };
        
        auto dd3 = TDF.Define("rap1", RapidityCal, {"E", "pz", "pdgid"});
        
        // From EPOS LHC:
        auto hist6 = dd3.Histo1D({"hist6", "Multiplicity CM", 100, -15, 15}, "rap1");
        
        // ******************************************************************************
        
        // Drawing
        auto c3 = new TCanvas("c3", "c3", 10, 10, 700, 500);
        c3->SetGrid(1,1);
        c3->SetLogx(0); // 0 == scale without Log, 1 == scale with Log.
        c3->SetLogy(1);
        
        //normalize histogram
        hist5->Scale(1/(hist5->Integral()));
        
        //normalize histogram
        hist6->Scale(1/(hist6->Integral()));
        
        hist5->GetYaxis()->SetTitle("dN/d#eta");
        hist5->GetXaxis()->SetTitle("#eta");
        hist5->SetMaximum(1);
        hist5->SetLineColor(kBlack);
        hist5->DrawClone();
        hist6->SetLineColor(kRed);
        hist6->DrawClone("same");
        
        // Draw the Legend 
        auto legend4 = new TLegend(0.1,0.7,0.48,0.9);
        legend4->AddEntry("hist5","CBJ Data","lep");
        legend4->Draw();
        
        // Draw the Legend 
        auto legend5 = new TLegend(0.1,0.7,0.48,0.9);
        legend5->AddEntry("hist6","PYTHIA 8 softQCD with E_{cut}","lep");
        legend5->Draw();
        
        
        // ******************************************************************************
        //                      Energy Distribuition CM: CBJ Data/EPOS LHC
        
        // From CBJ Data:
        auto hist7 = d2.Histo1D({"hist7", "Energy distribution", 100, -20, 20}, "Eta", "e");

        
        // Calculate rapidity and pass by a filter (Energy Cut)
        auto RapCal = [](doubles Es, doubles pzs) {
            auto all_RapCal  = 0.5*log((Es+pzs)/(Es-pzs));
            auto good_RapCal = all_RapCal[Es > 0.];
            return good_RapCal;
        };
        
        
        auto ddd1 = TDF.Define("rap2", RapCal, {"E", "pz"}).Define("good_E", "E[E>0]");
        auto hist8 = ddd1.Histo1D({"hist8", "Energy distribution", 100, -20, 20}, "rap2", "good_E");
    
        
        // Drawing
        auto c4 = new TCanvas("c4", "c4", 10, 10, 700, 500);
        c4->SetGrid(1,1);
        c4->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
        c4->SetLogy(1);
        
        //normalize histogram
        hist7->Scale(1/(hist7->Integral()));

        //normalize histogram
        hist8->Scale(1/(hist8->Integral()));
        
        hist7->GetYaxis()->SetTitle("dE/d#eta [GeV]");
        hist7->GetXaxis()->SetTitle("#eta");
        hist7->SetMaximum(1);
        hist7->SetLineColor(kBlack);
        hist7->DrawClone();
        
        hist8->SetLineColor(kRed);
        hist8->DrawClone("same");
        
        // Draw the Legend 
        auto legend6 = new TLegend(0.1,0.7,0.48,0.9);
        legend6->AddEntry("hist7","CBJ Data","lep");
        legend6->Draw();
        
        // Draw the Legend 
        auto legend7 = new TLegend(0.1,0.7,0.48,0.9);
        legend7->AddEntry("hist8","PYTHIA 8 softQCD with E_{cut}","lep");
        legend7->Draw();
        
    }
    
    int main(){
        TApplication app("app", nullptr, nullptr);
        EPOS_LHC_CBJ();
        app.Run();
    return 0;
    }
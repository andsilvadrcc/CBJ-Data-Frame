#include <ROOT/TDataFrame.hxx>
#include <TCanvas.h>
#include <TApplication.h>

using namespace ROOT::Experimental;
using namespace ROOT::Experimental::VecOps;

void Analysis_EPOS_LHC_test()
{
   TDataFrame d("Particle", "crmc_eposlhc_112108849_p_C_130000.root");

   // TVec supports per-element operations (a-la numpy) and simple filtering with v[v > 3]
   using doubles = TVec<double>;
   auto cutPt = [](doubles pxs, doubles pys, doubles Es) {
      auto all_pts = sqrt(pxs * pxs + pys * pys);
      auto good_pts = all_pts[Es > 200.];
      return good_pts;
   };

   auto hpt = d.Define("pt", cutPt, {"px", "py", "E"}).Histo1D({"hpt", "p_{T} distribution", 100, 0, 15}, "pt");

   // drawing
   auto c1 = new TCanvas("c1", "c1", 10, 10, 700, 500);
   c1->SetGrid(1, 1);
   c1->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
   c1->SetLogy(1);
   hpt->GetYaxis()->SetTitle("dN/dp_{T} [GeV^{-1}]");
   hpt->GetXaxis()->SetTitle("p_{T} [GeV]");
   hpt->DrawClone();
}

int main()
{
   TApplication app("app", nullptr, nullptr);
   Analysis_EPOS_LHC_test();
   app.Run();
   return 0;
}
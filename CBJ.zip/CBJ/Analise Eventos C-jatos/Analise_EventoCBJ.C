#include "TCanvas.h"
#include "TStyle.h"
#include "TH1.h"
#include "TGaxis.h"
#include "TLatex.h"
#include "TROOT.h"
#include "TGraphErrors.h"
#include "TF1.h"
#include "TLegend.h"
#include "TArrow.h"
#include <math.h>
#include "readevento1.C" // carrega as macros para leitura de uma arquivo txt
#include "WriteTxt.C"
#include "TFile.h"
#include "TTree.h"

#include <iostream>
#include <string>


//Definições da funções:
Double_t anguloTheta(Double_t , Double_t, Double_t );
Double_t MyEta(Double_t );
Double_t ErroPhi(Double_t , Double_t );
Double_t ErroTheta(Double_t , Double_t, Double_t  );
Double_t ErroPT(Double_t , Double_t , Double_t , Double_t );
Double_t ErroEta(Double_t , Double_t );
Double_t* BOOST(Double_t , Double_t , Double_t , Double_t , Double_t , Double_t, Double_t);





//****************************************************************************************************
// Funções
//****************************************************************************************************

    // função que calcula o ângulo theta
    Double_t anguloTheta(Double_t x, Double_t y, Double_t h) {
        return atan((TMath::Sqrt((x*x)+(y*y)))/h);
        
    }
    
    //função que calcula pseudorapidez
    Double_t MyEta(Double_t theta){
        return -0.5*(TMath::Log((1-cos(theta))/(1+cos(theta))));
    }
    
    //função Erro phi
    Double_t ErroPhi(Double_t x, Double_t y) { 
        return 0.0001/sqrt((x*x)+(y*y));

    }
    //função Erro theta
    Double_t ErroTheta(Double_t x, Double_t y, Double_t h) {
        return sqrt(((0.0001*0.0001)/(h*h)) + ((x*x+y*y)/(h*h*h*h)));

    }
    
    //função Erro momento tranversal
    Double_t ErroPT(Double_t theta, Double_t erroE1, Double_t E1, Double_t erroTheta) {
        return sqrt((pow(sin(theta),2))*(pow(erroE1,2))+(pow(E1*cos(theta),2))*(pow(erroTheta,2)));
    
    }
    
    //função Erro eta
    Double_t ErroEta(Double_t erroTheta, Double_t theta) {
        return sqrt((erroTheta)/sin(theta));

    }


//***************Transformação de Lorentz (geral em todas as direções)...//*********************
    
    Double_t* BOOST(Double_t betax, Double_t betay, Double_t betaz, Double_t px, Double_t py, Double_t pz, Double_t E1){
        
        Double_t A00, A11, A22, A33, A01, A02, A03, A12, A13, A23;
        
        // Parâmetro da velocidade, beta.
        Double_t beta = TMath::Sqrt((betax*betax)+(betay*betay)+(betaz*betaz));
        
        

        // fator de Lorentz.
        Double_t gama = 1/(TMath::Sqrt(1-(beta*beta)));
        
        
        //Elementos da matriz:
        A00 = gama;

        if(beta !=0){
        //Elementos simetricos na matriz:
        A01 = -1*(betax*gama);
        A02 = -1*(betay*gama);
        A03 = -1*(betaz*gama);

        
        
        //Elementos fora da diagonal
        A12 = (gama-1)*((betax*betay)/(beta*beta));
        A13 = (gama-1)*((betax*betaz)/(beta*beta));
        A23 = (gama-1)*((betay*betaz)/(beta*beta));
        
        //cout << gama << endl;

        //Elementos da diagonal
        
        
        A11 = (1+((gama-1)*((betax*betax)/(beta*beta))));
        A22 = (1+((gama-1)*((betay*betay)/(beta*beta))));
        A33 = (1+((gama-1)*((betaz*betaz)/(beta*beta))));
        }else
        {
            A11 = A22 = A33 = 1;
            A12 = A13 = A23 = 0;
            A01 = A02 = A03 = 0;
            
        }
        //Transformação de Lorentz.
        Double_t P0 = (A00*E1) + (A01*px) + (A02*py) + (A03*pz);              
        Double_t P1 = (A01*E1) + (A11*px) + (A12*py) + (A13*pz);
        Double_t P2 = (A02*E1) + (A12*px) + (A22*py) + (A23*pz);
        Double_t P3 = (A03*E1) + (A13*px) + (A23*py) + (A33*pz);


        //cout<<" Matriz de Transformação "<<endl;
        //cout<<" "<<A00<<"  "<<A01<<"  "<<A02<<"  "<<A03<<"  "<<endl;
        //cout<<" "<<A01<<"  "<<A11<<"  "<<A12<<"  "<<A13<<"  "<<endl;
        //cout<<" "<<A02<<"  "<<A12<<"  "<<A22<<"  "<<A23<<"  "<<endl;
        //cout<<" "<<A03<<"  "<<A13<<"  "<<A23<<"  "<<A33<<"  "<<endl;


        Double_t *vector = (Double_t*)malloc(4*sizeof(Double_t));  

        //retorna as variáveis transformadas.
        vector[0] = P0;
        vector[1] = P1;
        vector[2] = P2;
        vector[3] = P3;

        return vector;
    }

//****************************************************************************************************


//**********************************FUNÇÃO ROTAÇÃO****************************************************


    Double_t* ROTACAO(Double_t lNumerator, Double_t lDenominator, Double_t x, Double_t y){

    //cout<<"************************************************************************************"<<endl;
    //cout<<"**                                                                                **"<<endl;
    //cout<<"**       X = denominator = "<<lDenominator<<endl;
    //cout<<"**       Y = numerator   = "<<lNumerator<<endl;
    //cout<<"**                                                                                **"<<endl;
    //cout<<"**       Vetor Fluxo Direcional Q = (X,Y)                                         **"<<endl;
    //cout<<"**                                                                                **"<<endl;
    //cout<<"*********************************************************************************"<<endl;


    Double_t lAngle = TMath::Abs(TMath::ATan( lNumerator / lDenominator )/2);

    //cout<<"*************************************************************************"<<endl;
    //cout<<"**                                                                     **"<<endl;
    //cout<<"**   Angulo(rad) = "<<lAngle<<endl;
    //cout<<"**   Angulo(Grau) = "<<180.*lAngle/(TMath::Pi())<<endl;
    //cout<<"**                                                                     **"<<endl;
    //cout<<"*************************************************************************"<<endl;


    Double_t *vectorR = (Double_t*)calloc(3,sizeof(Double_t));    //calloc zera o vectorR.


        if(lDenominator > 0 && lNumerator > 0){
            
            lAngle = 0.5*TMath::Pi() - lAngle;
            
            vectorR[0] = x*(TMath::Cos(lAngle))-y*(TMath::Sin(lAngle)); 
            vectorR[1] = x*(TMath::Sin(lAngle))+y*(TMath::Cos(lAngle));
            vectorR[2] = atan2 (vectorR[1],vectorR[0]);


            //cout<<"********************************************"<<endl;
            //cout<<"**     Vetor Q : direcao do Quadrante 1   **"<<endl;
            //cout<<"********************************************"<<endl;
        }

        if(lDenominator < 0 && lNumerator > 0){
            
            lAngle = 1.5*TMath::Pi() - lAngle;

            vectorR[0] = x*(TMath::Cos(lAngle))-y*(TMath::Sin(lAngle)); 
            vectorR[1] = x*(TMath::Sin(lAngle))+y*(TMath::Cos(lAngle));
            vectorR[2] = atan2 (vectorR[1],vectorR[0]);


            //cout<<"********************************************"<<endl;
            //cout<<"**     Vetor Q : direcao do Quadrante 2   **"<<endl;
            //cout<<"********************************************"<<endl;

        }

        if(lDenominator < 0 && lNumerator < 0){
            lAngle = 0.5*TMath::Pi() + lAngle;
            
            vectorR[0] = x*(TMath::Cos(lAngle))-y*(TMath::Sin(lAngle)); 
            vectorR[1] = x*(TMath::Sin(lAngle))+y*(TMath::Cos(lAngle));
            vectorR[2] = atan2 (vectorR[1],vectorR[0]);


            //cout<<"********************************************"<<endl;
            //cout<<"**     Vetor Q : direcao do Quadrante 3   **"<<endl;
            //cout<<"********************************************"<<endl;
        }

        if(lDenominator > 0 && lNumerator < 0){


            lAngle = 0.5*TMath::Pi() + lAngle;

            vectorR[0] = x*(TMath::Cos(lAngle))-y*(TMath::Sin(lAngle)); 
            vectorR[1] = x*(TMath::Sin(lAngle))+y*(TMath::Cos(lAngle));
            vectorR[2] = atan2 (vectorR[1],vectorR[0]);


            //cout<<"********************************************"<<endl;
            //cout<<"**     Vetor Q : direcao do Quadrante 4   **"<<endl;
            //cout<<"********************************************"<<endl;
        }



    return vectorR;
        
    }


//************************************************************************************************************************

    void Analise_EventoCBJ(){

    #define N 20000


    //retirar a legenda estatística dos gráficos.
    //gStyle->SetOptStat(000000);


    //definição das variáveis.
    Double_t x[N], y[N], phi[N],x1[N], y1[N], E1[N], e[N], theta[N], eta[N], PT[N], erroE1[N], PCM[N], pz[N], ECM[N], ET[N], Energy[N];
    Double_t ErroPhi1[N], erroTheta[N], erroPT[N], erroEta[N], px[N], py[N], momentoA[N], E1T[N], pxT[N], pyT[N], pzT[N], rapidity[N] ;
    Double_t somaE=0, somaMomentoA=0, xT=0, yT=0, xM=0, yM=0, aux1=0, aux2=0,xcpe=0, ycpe=0, AnguloZenitalPPI = 0,  WLP = 0;
    Double_t somapx=0, somapy=0, somapz=0, betax=0, betay=0, betaz=0, beta=0, FatorC, h, somaE1T =0, somaPT =0,  mediaPT =0, momentoLAB =0;
    int indiceLP;

    // 87 eventos C-jatos.
    // altura 152 cm + 11.5 cm metade do alvo de Carbono + 5cm de madeira suporte.
    cout<<"*****************************************************************************************"<<endl;
    cout<<"                                                                                       **"<<endl;

    // altura 152 cm + 5 cm (suporte de madeira) + 11.5 cm (metade do alvo de Carbono).
    Double_t H = 168.5;

    //Double_t H = 72000;// 72000 cm --> 720 m. altura estimada do Evento Centauro.

    //int lNpts = readevento1("evento1517.txt",x,y,E1);FatorC =0.0073;AnguloZenitalPPI = atan(0.1860); h = (H/cos(AnguloZenitalPPI)); //20.96 TeV
    //int lNpts = readevento1("evento1528.txt",x,y,E1);FatorC = 0.0061; AnguloZenitalPPI = atan(0.5700) ;h = H/cos(AnguloZenitalPPI); //30.34 TeV
    //int lNpts = readevento1("evento1543.txt",x,y,E1);FatorC = 0.0097; AnguloZenitalPPI = atan(0.3400);h = (H/cos(AnguloZenitalPPI));  //24.74 TeV
    int lNpts= readevento1("evento1547.txt",x,y,E1); FatorC = 0.0018; AnguloZenitalPPI = atan(0.3900);h = (H/cos(AnguloZenitalPPI)); //92.55 TeV
    //int lNpts= readevento1("evento1567.txt",x,y,E1); FatorC = 0.0117;  AnguloZenitalPPI = atan(0.1850);h = (H/cos(AnguloZenitalPPI)); //21.76 TeV
    //int lNpts= readevento1("evento156725.txt",x,y,E1); FatorC = 0.0072; AnguloZenitalPPI = atan(0.9310);h =(H/cos(AnguloZenitalPPI));// 24.67 TeV
    //int lNpts= readevento1("evento1576.txt",x,y,E1); FatorC = 0.006; AnguloZenitalPPI = atan(0.3000);h = (H/cos(AnguloZenitalPPI));//19.67 TeV
    //int lNpts= readevento1("evento1577.txt",x,y,E1); FatorC = 0.0061; AnguloZenitalPPI = atan(0.0000);h = (H/cos(AnguloZenitalPPI)); //27.94 TeV
    //int lNpts= readevento1("evento1584.txt",x,y,E1); FatorC = 0.012; AnguloZenitalPPI = atan(0.3600);h = (H/cos(AnguloZenitalPPI)); //18.70 TeV
    //int lNpts= readevento1("evento1597.txt",x,y,E1); FatorC = 0.0044; AnguloZenitalPPI = atan(0.8020);  h = (H/cos(AnguloZenitalPPI));//62.53 TeV
    //int lNpts= readevento1("evento15102.txt",x,y,E1); FatorC = 0.008; AnguloZenitalPPI = atan(0.5400);h = (H/cos(AnguloZenitalPPI)); //34.06 TeV
    //int lNpts= readevento1("evento15105.txt",x,y,E1); FatorC = 0.0176; AnguloZenitalPPI = atan(0.0000); h = (H/cos(AnguloZenitalPPI));//35.02 TeV
    //int lNpts= readevento1("evento15115.txt",x,y,E1);FatorC = 0.016; AnguloZenitalPPI = atan(0.5010);h = (H/cos(AnguloZenitalPPI));//76.62 TeV
    //int lNpts= readevento1("evento15150.txt",x,y,E1);FatorC = 0.0088; AnguloZenitalPPI = atan(0.7240);h = (H/cos(AnguloZenitalPPI));//19.38 TeV
    //int lNpts= readevento1("evento15156.txt",x,y,E1); FatorC = 0.004;  AnguloZenitalPPI = atan(0.0000); h = (H/cos(AnguloZenitalPPI));//24.85 TeV
    //int lNpts= readevento1("evento15159.txt",x,y,E1);FatorC = 0.004;  AnguloZenitalPPI = atan(0.0000); h = (H/cos(AnguloZenitalPPI));//22.97 TeV
    //int lNpts= readevento1("evento151614.txt",x,y,E1);FatorC = 0.0044; AnguloZenitalPPI = atan(0.8820);h = (H/cos(AnguloZenitalPPI));// 16.91 TeV
    //int lNpts= readevento1("evento1680.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.6900); h = (H/cos(AnguloZenitalPPI));// 36.86 TeV
    //int lNpts= readevento1("evento1685.txt",x,y,E1);FatorC = 0.0035; AnguloZenitalPPI = atan(0.1100);h = (H/cos(AnguloZenitalPPI));//20.84 TeV
    //int lNpts= readevento1("evento1686.txt",x,y,E1);FatorC = 0.0035; AnguloZenitalPPI = atan(0.7420);h = (H/cos(AnguloZenitalPPI));//118.75 TeV
    //int lNpts= readevento1("evento1691.txt",x,y,E1);FatorC = 0.0142; AnguloZenitalPPI = atan(0.4320);h = (H/cos(AnguloZenitalPPI));//29.45  TeV
    //int lNpts= readevento1("evento1696.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.1500);h = (H/cos(AnguloZenitalPPI));//24.01 TeV
    //int lNpts= readevento1("evento16101.txt",x,y,E1);FatorC = 0.0034; AnguloZenitalPPI = atan(0.1000);h = (H/cos(AnguloZenitalPPI)); //52.75 TeV
    //int lNpts= readevento1("evento16105.txt",x,y,E1);FatorC = 0.0142; AnguloZenitalPPI = atan(0.4110);h = (H/cos(AnguloZenitalPPI));//  26.23 TeV
    //int lNpts= readevento1("evento17192.txt",x,y,E1);FatorC = 0.003; AnguloZenitalPPI = atan(0.5960);h = (H/cos(AnguloZenitalPPI)); //99.77 TeV
    //int lNpts= readevento1("evento1769.txt",x,y,E1);FatorC = 0.0033; AnguloZenitalPPI = atan(0.0000);h = (H/cos(AnguloZenitalPPI));//33.25 TeV
    //int lNpts= readevento1("evento17791.txt",x,y,E1);FatorC = 0.0033; AnguloZenitalPPI = atan(0.6510);h = (H/cos(AnguloZenitalPPI));//31.10 TeV
    //int lNpts= readevento1("evento17792.txt",x,y,E1);FatorC = 0.0033; AnguloZenitalPPI = atan(0.2590); h = (H/cos(AnguloZenitalPPI));//34.44 TeV
    //int lNpts= readevento1("evento17841.txt",x,y,E1);FatorC = 0.0072;  AnguloZenitalPPI = atan(0.2500);h = (H/cos(AnguloZenitalPPI));//23.54 TeV
    //int lNpts= readevento1("evento17842.txt",x,y,E1);FatorC = 0.0074;  AnguloZenitalPPI = atan(0.9490);h = (H/cos(AnguloZenitalPPI));//22.45 TeV
    //int lNpts= readevento1("evento1786.txt",x,y,E1);FatorC = 0.0072;   AnguloZenitalPPI = atan(0.4350);h = (H/cos(AnguloZenitalPPI));//40.83  TeV
    //int lNpts= readevento1("evento1789.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.9500);h = (H/cos(AnguloZenitalPPI));// 25.81 TeV
    //int lNpts= readevento1("evento1790.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.1670);h = (H/cos(AnguloZenitalPPI));//41.91 TeV
    //int lNpts= readevento1("evento17961.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.7500);h = (H/cos(AnguloZenitalPPI));// 33.66 TeV
    //int lNpts= readevento1("evento17962.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.1000);h = (H/cos(AnguloZenitalPPI));// 20.10 TeV
    //int lNpts= readevento1("evento171022.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.3700);h = (H/cos(AnguloZenitalPPI));// 31.88 TeV
    //int lNpts= readevento1("evento171024.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.4620);h = (H/cos(AnguloZenitalPPI));//22.14 TeV
    //int lNpts= readevento1("evento17104.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.2500);h = (H/cos(AnguloZenitalPPI)); //23.23 TeV
    //int lNpts= readevento1("evento17105.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.3000);h = (H/cos(AnguloZenitalPPI));// 32.32 TeV
    //int lNpts= readevento1("evento17115.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.4290);h = (H/cos(AnguloZenitalPPI));//21.43 TeV
    //int lNpts= readevento1("evento17122.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.6150);h = (H/cos(AnguloZenitalPPI)); //24.62 TeV
    //int lNpts= readevento1("evento17124.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.8700);h = (H/cos(AnguloZenitalPPI));// 41.92 TeV
    //int lNpts= readevento1("evento17130.txt",x,y,E1);FatorC = 0.01;AnguloZenitalPPI = atan(0.1400);h = (H/cos(AnguloZenitalPPI)); //38.94 TeV
    //int lNpts= readevento1("evento17132.txt",x,y,E1);FatorC = 0.0036; AnguloZenitalPPI = atan(0.2080);h = (H/cos(AnguloZenitalPPI)); //28.20 TeV
    //int lNpts= readevento1("evento171351.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.4900);h = (H/cos(AnguloZenitalPPI)); //45.88 TeV
    //int lNpts= readevento1("evento171354.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.0000);h = (H/cos(AnguloZenitalPPI)); //22.87 Te
    //int lNpts= readevento1("evento17136.txt",x,y,E1);FatorC = 0.0072;  AnguloZenitalPPI = atan(0.2270);h = (H/cos(AnguloZenitalPPI));//110.48 TeV
    //int lNpts= readevento1("evento171382.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.3830);h = (H/cos(AnguloZenitalPPI));// 23.04 TeV
    //int lNpts= readevento1("evento171388.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.2000);h = (H/cos(AnguloZenitalPPI)); //22.68 TeV
    //int lNpts= readevento1("evento17140.txt",x,y,E1);FatorC = 0.0072;  AnguloZenitalPPI = atan(0.2220);h = (H/cos(AnguloZenitalPPI));//31.02 TeV
    //int lNpts= readevento1("evento17148.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.5560);h = (H/cos(AnguloZenitalPPI)); //20.34 TeV
    //int lNpts= readevento1("evento17150.txt",x,y,E1);FatorC = 0.0036;  AnguloZenitalPPI = atan(0.6450);h = (H/cos(AnguloZenitalPPI)); //86.17 TeV
    //int lNpts= readevento1("evento17159.txt",x,y,E1);FatorC = 0.0072;  AnguloZenitalPPI = atan(0.5830);h = (H/cos(AnguloZenitalPPI)); //21.63 TeV
    //int lNpts= readevento1("evento17164.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.3330);h = (H/cos(AnguloZenitalPPI)); //113.07 TeV
    //int lNpts= readevento1("evento1821.txt",x,y,E1);FatorC = 0.0036; AnguloZenitalPPI = atan(0.0000);h = (H/cos(AnguloZenitalPPI)); //65.92 TeV
    //int lNpts= readevento1("evento1824.txt",x,y,E1);FatorC = 0.0066; AnguloZenitalPPI = atan(0.9090);h = (H/cos(AnguloZenitalPPI)); //30.81 TeV
    //int lNpts= readevento1("evento1828.txt",x,y,E1);FatorC = 0.0033; AnguloZenitalPPI = atan(1.1700); h = (H/cos(AnguloZenitalPPI)); //27.28 TeV
    //int lNpts= readevento1("evento1830.txt",x,y,E1);FatorC = 0.0036;  AnguloZenitalPPI = atan(0.5500);h = (H/cos(AnguloZenitalPPI));  //68.64 TeV
    //int lNpts= readevento1("evento1832.txt",x,y,E1);FatorC = 0.0036; AnguloZenitalPPI = atan(0.5500);h = (H/cos(AnguloZenitalPPI)); //57.79 TeV
    //int lNpts= readevento1("evento1845.txt",x,y,E1);FatorC = 0.0033; AnguloZenitalPPI = atan(0.5010);h = (H/cos(AnguloZenitalPPI)); //41.90 TeV
    //int lNpts= readevento1("evento1847.txt",x,y,E1);FatorC = 0.0066; AnguloZenitalPPI = atan(1.0000);h = (H/cos(AnguloZenitalPPI)); //29.45 TeV
    //int lNpts= readevento1("evento1849.txt",x,y,E1);FatorC = 0.0066; AnguloZenitalPPI = atan(0.9040); h = (H/cos(AnguloZenitalPPI));  //48.61 TeV
    //int lNpts= readevento1("evento1869.txt",x,y,E1);FatorC = 0.003;  AnguloZenitalPPI = atan(0.9040);h = (H/cos(AnguloZenitalPPI));//42.45 TeV
    //int lNpts= readevento1("evento187330.txt",x,y,E1);FatorC = 0.009; AnguloZenitalPPI = atan(0.0000);h = (H/cos(AnguloZenitalPPI)); //25.56 TeV
    //int lNpts= readevento1("evento187650.txt",x,y,E1);FatorC = 0.009; AnguloZenitalPPI = atan(0.0000);h = (H/cos(AnguloZenitalPPI)); //22.38 TeV
    //int lNpts= readevento1("evento1892.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.1700);h = (H/cos(AnguloZenitalPPI)); //20.37 TeV
    //int lNpts= readevento1("evento1893.txt",x,y,E1);FatorC = 0.0072;AnguloZenitalPPI = atan(0.2000);h = (H/cos(AnguloZenitalPPI)); //27.54 TeV
    //int lNpts= readevento1("evento18110.txt",x,y,E1);FatorC = 0.01;  AnguloZenitalPPI = atan(0.3100);h = (H/cos(AnguloZenitalPPI));//37.20 TeV
    //int lNpts= readevento1("evento18139.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.5150);h = (H/cos(AnguloZenitalPPI)); //20.41 TeV
    //int lNpts= readevento1("evento18145.txt",x,y,E1);FatorC = 0.005;  AnguloZenitalPPI = atan(0.6670);h = (H/cos(AnguloZenitalPPI));//41.28 TeV
    //int lNpts= readevento1("evento18149.txt",x,y,E1);FatorC = 0.0023; AnguloZenitalPPI = atan(0.6670);h = (H/cos(AnguloZenitalPPI));//70.30 TeV
    //int lNpts= readevento1("evento19100.txt",x,y,E1);FatorC = 0.005;  AnguloZenitalPPI = atan(0.0000);h = (H/cos(AnguloZenitalPPI));//28.13 TeV
    //int lNpts= readevento1("evento19101.txt",x,y,E1);FatorC = 0.0025;  AnguloZenitalPPI = atan(0.0000);h = (H/cos(AnguloZenitalPPI));//138.91 TeV
    //int lNpts= readevento1("evento19105.txt",x,y,E1);FatorC = 0.0144; AnguloZenitalPPI = atan(0.1500);h = (H/cos(AnguloZenitalPPI)); //21.40 TeV
    //int lNpts= readevento1("evento19107.txt",x,y,E1);FatorC = 0.005; AnguloZenitalPPI = atan(0.3600);h = (H/cos(AnguloZenitalPPI));//21.29 TeV
    //int lNpts= readevento1("evento19108.txt",x,y,E1);FatorC = 0.0072;  AnguloZenitalPPI = atan(0.5000);h = (H/cos(AnguloZenitalPPI));//24.14 TeV
    //int lNpts= readevento1("evento19115.txt",x,y,E1);FatorC = 0.01;  AnguloZenitalPPI = atan(0.5000);h = (H/cos(AnguloZenitalPPI)); //57.45 TeV
    //int lNpts= readevento1("evento191214.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.0000);h = (H/cos(AnguloZenitalPPI)); //21.30 TeV
    //int lNpts= readevento1("evento191215.txt",x,y,E1);FatorC = 0.005; AnguloZenitalPPI = atan(0.6000);h = (H/cos(AnguloZenitalPPI));//20.19 TeV
    //int lNpts= readevento1("evento19127.txt",x,y,E1);FatorC = 0.005;  AnguloZenitalPPI = atan(0.5000);h = (H/cos(AnguloZenitalPPI));//21.51 TeV
    //int lNpts= readevento1("evento19129.txt",x,y,E1);FatorC = 0.0064; AnguloZenitalPPI = atan(0.8400);h = (H/cos(AnguloZenitalPPI));//21.81 TeV
    //int lNpts= readevento1("evento191361.txt",x,y,E1);FatorC = 0.0064; AnguloZenitalPPI = atan(0.0000);h = (H/cos(AnguloZenitalPPI));//58.14 TeV
    //int lNpts= readevento1("evento191362.txt",x,y,E1);FatorC = 0.0025; AnguloZenitalPPI = atan(0.3000);h = (H/cos(AnguloZenitalPPI));//82.18 TeV
    //int lNpts= readevento1("evento19137.txt",x,y,E1);FatorC = 0.005; AnguloZenitalPPI = atan(0.4400); h = (H/cos(AnguloZenitalPPI));//41.97 TeV
    //int lNpts= readevento1("evento19138.txt",x,y,E1);FatorC = 0.0025; AnguloZenitalPPI = atan(0.000);h = (H/cos(AnguloZenitalPPI));//29.00 TeV
    
    
    //int lNpts= readevento1("evento17153.txt",x,y,E1);FatorC = 0.01; AnguloZenitalPPI = atan(0.4290);h = (H/cos(AnguloZenitalPPI));//44.02 TeV

    //Evento Centauro
    //int lNpts = readevento1("CentauroV.txt",x,y,E1); FatorC = 0.1 ; AnguloZenitalPPI = 0; h = (H/cos(AnguloZenitalPPI));
    
    


    //Tamanho do eixo.
    Double_t eixo = 0.1;

    //numero de casas de precisão:
    cout<<fixed;
    cout<<setprecision(4);

    cout<<"                                                                                       **"<<endl;
    cout<<"*****************************************************************************************"<<endl;
    cout<<"**                                                                                     **"<<endl;
    cout<<"                   Posicao e Energia do Evento"<<endl;
    cout<<"**                                                                                     **"<<endl;
    for(long i=0; i<lNpts; i++){ 

    cout<<"  "<<i+1<<"       x = "<<x[i]<<"           y = "<<  y[i] <<"           E = "<<E1[i]<<" TeV "<<endl;


    }
    cout<<"**                                                                                     **"<<endl;
    cout<<"******************************************************************************************"<<endl;

    cout<<"**********************************************************************************************************"<<endl;
    cout<<"**                                                                                                      **"<<endl;
    cout<<"**          Fator de Transformação de unidades = "<<FatorC<<" cm"<<endl;
    cout<<"**                                                                                                      **"<<endl;
    cout<<"**          Tangente do Ângulo Zenital =  "<<tan(AnguloZenitalPPI)<<endl;
    cout<<"**                                                                                                      **"<<endl;
    cout<<"**          Angulo Zenital =  "<<AnguloZenitalPPI<<" rad "<<endl;
    cout<<"**                                                                                                      **"<<endl;
    cout<<"**   Altura entre a câmara superior e o suporte de  madeira : H = 152 cm "<<endl;
    cout<<"**                                                                                                      **"<<endl;
    cout<<"**   Aproximaçao: vértice de interação na metade do alvo (23 cm) de carbono: d =23/2 = 11.5 cm       "<<endl;
    cout<<"**                                                                                                      **"<<endl;
    cout<<"**   h = H + d = "<<H<<" cm  "<<" cos(Ângulo Zenital) = "<<cos(AnguloZenitalPPI)<<"  H' = h/cos(Ângulo Zenital) = "<<h<<" cm "<<endl;
    cout<<"**                                                                                                      **"<<endl;
    cout<<"**********************************************************************************************************"<<endl;

    //cálculo da conversão das medidas do evento.
    for(long i=0; i<lNpts; i++){  
        Energy[i] = E1[i]*1000;   //em GeV.
        

        somaE += E1[i]; // Energia total do evento em TeV.
        aux1 += x[i]*E1[i];
        aux2 += y[i]*E1[i];


    }
    
    //Coordenadas do centro ponderado de energia - CPE.
    xcpe = aux1/somaE;
    ycpe = aux2/somaE;
    
    
    cout << " Energia total = " << somaE <<" TeV " << endl;
    
    cout<<"***************************************************************************************"<<endl;
    cout<<"**         Correção da posição para a frente de chegada das partículas               **"<<endl;
    cout<<"           para o Plano Perpendicular de Incidência - PPI  "<<endl;
    cout<<"**                                                                                   **"<<endl;
    for(long i=0; i<lNpts; i++){ 
        
        cout<<"       x = "<<x[i]<<" cm      y = "<<  y[i] <<" cm      E = "<<E1[i]<<" TeV "<<endl;

    }
    cout<<"**                                                                                   **"<<endl;
    cout<<"***************************************************************************************"<<endl;

    cout<<"************************************************************************************"<<endl;
    cout<<"**                Centro Ponderado de Energia - CPE                               **"<<endl;
    cout<<"**                                                                                **"<<endl;
    cout<<"**          xCPE =  "<<xcpe<<" cm     yCPE =  "<<ycpe<<" cm "<<endl;
    cout<<"**                                                                                **"<<endl;
    cout<<"************************************************************************************"<<endl;

    cout<<"***************************************************************************************"<<endl;
    cout<<"**                                                                                   **"<<endl;
    cout<<"                   Posição corrigida para CPE "<<endl;
    cout<<"**                                                                                   **"<<endl;

    for(long i=0; i<lNpts; i++){ 
        
        //As coordenadas no referencial do Centro Ponderado de Energia - CPE.
        x[i] = x[i] - xcpe;
        y[i] = y[i] - ycpe;

        x[i] = FatorC*x[i]*cos(AnguloZenitalPPI); // conversão para cm
        y[i] = FatorC*y[i]*cos(AnguloZenitalPPI);	

        cout<<"HERE       x = "<<x[i]<<"           y = "<<  y[i] <<"           E = "<<E1[i]<<" TeV "<<endl;

        theta[i]= anguloTheta(x[i], y[i], h); //ângulo Theta em radiano.
        eta[i] = MyEta(theta[i]); //Pseudo-rapidity.

        phi[i] = atan2(y[i],x[i]); //atan2 retorna o ângulo azimutal(rad) para o quadrante correspondente.

        
        PT[i] = 1000*E1[i]*sin(theta[i]); //momento transversal.
        px[i] = PT[i]*cos(phi[i]);
        py[i] = PT[i]*sin(phi[i]);
        pz[i] =1000*E1[i]*cos(theta[i]); // momento longitudinal.

        cout << "px = "<< px[i] << " py =" << py[i]  << "  pz = "<< pz[i] << "  E = " << E1[i] << " phi = " << phi[i] << " rad" << endl;
    }
    
    
    
    //WriteTxt(px,py,pz,Energy,lNpts,"quadrimomentos.txt");
    
    // Set up the ROOT Save TFile and TTree.
    TFile *file = TFile::Open("dataCBJ_QCD.root","recreate");
    TTree *Tree = new TTree("Tree","Tree");

    //variables
    Double_t Px, Py, Pz, En;
    
    Tree->Branch("Px",&Px);
    Tree->Branch("Py",&Py);
    Tree->Branch("Pz",&Pz);
    Tree->Branch("En",&En);

    for (long i = 0; i < lNpts; i++) {
        
        Px = px[i];
        Py = py[i];
        Pz = pz[i];
        En  = Energy[i];
        
        Tree->Fill();
    }

    //  Write tree.
    Tree->Print();
    Tree->Write();
    delete file;
    
    //******************************************************************************
    // Multiplicity in Phase Space
    //******************************************************************************
    TCanvas *c1 = new TCanvas("c1","c1",300,10,600,500);

    TH2F *hist1 = new TH2F("hist1","Histograma",50,0,15,50,-TMath::Pi(),TMath::Pi());


    for (long i = 0; i < lNpts; i++) {
        hist1->Fill(eta[i],phi[i]);

    }
    // histogram
    hist1->GetXaxis()->SetTitle("#eta");
    hist1->GetYaxis()->SetTitle("#phi [rad]");
    hist1->GetZaxis()->SetTitle("dN/d#etad#phi [rad^{-1}]");
    hist1->SetLineColor(kBlue);
    hist1->Draw("COLZ");

    // draw the legend
    TLegend *legend1= new TLegend(0.6,1,0.88,0.85);
    legend1->SetTextFont(72);
    legend1->SetTextSize(0.04);
    legend1->AddEntry(hist1,"Data CBJ","lpe");
    legend1->Draw();
    
    //******************************************************************************
    // Distribution Energy in Phase Space
    //******************************************************************************
    
    TCanvas *c2 = new TCanvas("c2","Evento-Histograma",300,10,600,500);

    TH1F *hist2 = new TH1F("hist2","Histograma",50,0,17);


    for (long i = 0; i < lNpts; i++) {
        hist2->Fill(eta[i], E1[i]);

    }

    hist2->GetXaxis()->SetTitle("#eta");
    hist2->GetYaxis()->SetTitle("dE/d#eta [TeV]");
    hist2->SetLineColor(kBlue);
    hist2->Draw();

    // draw the legend
    TLegend *legend2=new TLegend(0.6,1,0.88,0.85);
    legend2->SetTextFont(72);
    legend2->SetTextSize(0.04);
    legend2->AddEntry(hist2,"Data CBJ","lpe");
    legend2->Draw();
    
    //******************************************************************************
    // Distribution in Phase Space
    //******************************************************************************
    
    TCanvas *c3 = new TCanvas("c3","Evento-Histograma",300,10,600,500);

    c3->SetGridx();    // Horizontal grid
    c3->SetGridy();    // Vertical grid

    TH1F *hist3 = new TH1F("hist3","Histograma",100,0,15);

    for (long i = 0; i < lNpts; i++) {
        hist3->Fill(eta[i]);
        
    }

    hist3->GetXaxis()->SetTitle("#eta");
    hist3->GetYaxis()->SetTitle("dN/d#eta");
    hist3->SetLineColor(kBlue);
    hist3->Draw();

    // draw the legend
    TLegend *legend3=new TLegend(0.6,1,0.88,0.85);
    legend3->SetTextFont(72);
    legend3->SetTextSize(0.04);
    legend3->AddEntry(hist3,"Data CBJ","lpe");
    legend3->Draw();
    
    //******************************************************************************
    // Energy in Phase Space
    //******************************************************************************
    TCanvas *c4 = new TCanvas("c4","c4",300,10,600,500);
    c4->SetGridx();    // Horizontal grid
    c4->SetGridy();    // Vertical grid

    TH2F *hist4 = new TH2F("hist4","Phase Space",50,0,15,50,-TMath::Pi(),TMath::Pi());


    for (long i = 0; i < lNpts; i++) {
        hist4->Fill(eta[i],phi[i],E1[i]);   

    }
    // histogram
    hist4->GetXaxis()->SetTitle("#eta");
    hist4->GetYaxis()->SetTitle("#phi [rad]");
    hist4->GetZaxis()->SetTitle("dE/d#etad#phi [TeV/rad]");
    hist4->SetLineColor(kBlue);
    hist4->Draw("COLZ");

    // draw the legend
    TLegend *legend4= new TLegend(0.6,1,0.88,0.85);
    legend4->SetTextFont(72);
    legend4->SetTextSize(0.04);
    legend4->AddEntry(hist4,"Data CBJ","lpe");
    legend4->Draw();
    
    
    TCanvas *c5 = new TCanvas("c5","c5",300,10,600,500);
    c5->SetGridx();    // Horizontal grid
    c5->SetGridy();    // Vertical grid

    TH2F *hist5 = new TH2F("hist5","Phase Space",50,-20,20,50,-20,20);


    for (long i = 0; i < lNpts; i++) {
        hist5->Fill(x[i]*1000,y[i]*1000, E1[i]);
        
        cout << " x = " << x[i] << "  y = " << y[i] << endl;

    }
    // histogram
    hist5->GetXaxis()->SetTitle(" x [#mum]");
    hist5->GetYaxis()->SetTitle(" y [#mum]");
    hist5->GetZaxis()->SetTitle("E [TeV=]");
    hist5->SetLineColor(kBlue);
    hist5->Draw("COLZ");
    
  

    }

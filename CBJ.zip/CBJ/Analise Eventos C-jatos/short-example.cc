#include "fastjet/ClusterSequence.hh"
#include <fastjet/SISConePlugin.hh>
#include "fastjet/D0RunIConePlugin.hh"
#include <iostream>
#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TBrowser.h"
#include "TH1.h"
#include "TH1F.h"
#include "TH2.h"
#include "TH2F.h"
#include "TCanvas.h"
#include "TRandom.h"
#include "TMath.h"
#include <iostream>


//-------the various families of jet-clustering algorithm

//Enumerator:
//kt_algorithm  the longitudinally invariant kt algorithm

//cambridge_algorithm  the longitudinally invariant variant of the cambridge algorithm (aka Aachen algoithm).

//antikt_algorithm  like the k_t but with distance measures dij = min(1/kti^2,1/ktj^2) Delta R_{ij}^2 / R^2 diB = 1/kti^2

//.root from C-jato to fastjet


using namespace fastjet;
using namespace std;

int main () {
    
    TFile *fin = new TFile("dataCBJ_QCD.root");
    TTree *Tree = (TTree*)fin->Get("Tree"); 

    Double_t Px, Py, Pz, En, Eta, pt, Phi;
    Double_t Px1[20000], Py1[20000], Pz1[20000], En1[20000];

    Tree->SetBranchAddress("Px",&Px);
    Tree->SetBranchAddress("Py",&Py);
    Tree->SetBranchAddress("Pz",&Pz);
    Tree->SetBranchAddress("En",&En);
    
    Int_t nentries = (Int_t)Tree->GetEntries();
    
    //cout <<"  N === " << nentries << endl;
    
    
    for (Int_t i=0; i< nentries; i++) {
        Tree->GetEntry(i);
        Px1[i] = Px;
        Py1[i] = Py;
        Pz1[i] = Pz;
        En1[i] = En;
    }
    
    Int_t p =0;
    Float_t Jphi[20000], Jpt[20000], Jrap[20000];

    vector<PseudoJet> particles;
    // an event with three particles:   px     py      pz     E
    for (Int_t i=0; i< nentries; i++) {
        particles.push_back( PseudoJet(Px1[i],Py1[i],Pz1[i],En1[i]) );
        
        //cout << i << " " << En1[i] << endl;
        
        
    }



    double R = 0.7;

    //JetDefinition jet_def(kt_algorithm, R);
    //JetDefinition jet_def(cambridge_algorithm, R);
    JetDefinition jet_def(antikt_algorithm, R);




    // run the clustering, extract the jets
    ClusterSequence cs(particles, jet_def);
    vector<PseudoJet> jets = sorted_by_pt(cs.inclusive_jets());

    // print out some infos
    cout << "Clustering with " << jet_def.description() << endl;

    // print the jets
    cout <<   "        pt [GeV]  y  phi [rad]" << endl;

    for (unsigned i = 0; i < jets.size(); i++) {
        cout << "'jet " << i << ": "<< jets[i].pt() << " " 
        << jets[i].rap() << " " << jets[i].phi_std() <<"'  //mass jet =  "<< jets[i].m()  << " GeV "<< endl;
        
        Jphi[i] = jets[i].phi_std();
        Jpt[i]  = jets[i].pt();
        Jrap[i] = jets[i].rap();
        p++;


        vector<PseudoJet> constituents = jets[i].constituents();
        for (unsigned j = 0; j < constituents.size(); j++) {
            cout << "    constituent " << j << " pt: " << constituents[j].pt() << " phi = "<< constituents[j].phi_std() << " mass    = "<< constituents[j].m() << " GeV "<< endl;
        }
    }
    
    //******************************************************************************


    TCanvas *c1 = new TCanvas("c1","c1",800,1000);
    TH2F *jts1 = new TH2F("jts1","p_{T} of the jets in #phi",50,0,17,50,-TMath::Pi(),TMath::Pi());

    for(Int_t i =0; i < 6; i++){
        jts1->Fill(Jrap[i],Jphi[i],Jpt[i]);
        
    }

    jts1->GetYaxis()->SetTitle("#phi [rad]");
    jts1->GetXaxis()->SetTitle("#eta ");
    jts1->GetZaxis()->SetTitle("p_{T} [GeV]");
    jts1->Draw("COLZ");


    
    //***********************************************************************************

    
}

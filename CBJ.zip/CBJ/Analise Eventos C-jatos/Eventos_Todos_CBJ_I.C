#include "TCanvas.h"
#include "TStyle.h"
#include "TH1.h"
#include "TGaxis.h"
#include "TLatex.h"
#include "TROOT.h"
#include "TGraphErrors.h"
#include "TF1.h"
#include "TLegend.h"
#include "TArrow.h"
#include <math.h>
#include "TFile.h"
#include "TTree.h"

#include <iostream>
#include <string>


//Definições da funções:
Double_t anguloTheta(Double_t , Double_t, Double_t );
Double_t MyEta(Double_t );
Double_t ErroPhi(Double_t , Double_t );
Double_t ErroTheta(Double_t , Double_t, Double_t  );
Double_t ErroPT(Double_t , Double_t , Double_t , Double_t );
Double_t ErroEta(Double_t , Double_t );
Double_t* BOOST(Double_t , Double_t , Double_t , Double_t , Double_t , Double_t, Double_t);


#include "readevento1.C"  // carrega as macros para leitura de uma arquivo txt
#include "Write.C"

// **************** Funções ***************************

    // função que calcula o ângulo theta
    Double_t anguloTheta(Double_t x, Double_t y, Double_t h) {

    Double_t angulotheta = atan((TMath::Sqrt((x*x)+(y*y)))/h); 

        return angulotheta;
    }
    //função que calcula pseudorapidez
    Double_t MyEta(Double_t theta){ //função para calcular a pseudorapidity

    Double_t Eta = -0.5*(TMath::Log((1-cos(theta))/(1+cos(theta))));


    return Eta;
    }
    //função Erro phi

    Double_t ErroPhi(Double_t x, Double_t y) {

    Double_t ErrosPhi = 0.0001/TMath::Sqrt((x*x)+(y*y));

    return ErrosPhi;
    }
    //função Erro theta

    Double_t ErroTheta(Double_t x, Double_t y) {

    Double_t ErrosTheta = TMath::Sqrt((1.1197*1e-17)+(1.268*1e-22)*(x*x+y*y))/(28900+(x*x)+(y*y));

    return ErrosTheta;
    }
    //função Erro momento tranversal

    Double_t ErroPT(Double_t theta, Double_t erroE1, Double_t E1, Double_t erroTheta) {

    Double_t ErrosPT = TMath::Sqrt((sin(theta))*(sin(theta))*(erroE1*erroE1)+(E1*cos(theta))*(E1*cos(theta))*erroTheta*erroTheta);

    return ErrosPT;
    }
    //função Erro Pseudorapidez eta

    Double_t ErroEta(Double_t erroTheta, Double_t theta) {

    Double_t ErrosEta = erroTheta/sin(theta);

    return ErrosEta;
}

//***************Transformação de Lorentz (geral em todas as direções)...*********************

    Double_t* BOOST(Double_t betax, Double_t betay, Double_t betaz, Double_t px, Double_t py, Double_t pz, Double_t E1){
        
        Double_t A00, A11, A22, A33, A01, A02, A03, A12, A13, A23;

        // Parâmetro da velocidade, beta.
        Double_t beta = TMath::Sqrt((betax*betax)+(betay*betay)+(betaz*betaz));

        // fator de Lorentz.
        Double_t gama = 1/(TMath::Sqrt(1-(beta*beta)));

        //Elementos da matriz:
        A00 = gama;

        if(beta !=0){
        //Elementos simetricos na matriz:
        A01 = -1*(betax*gama);
        A02 = -1*(betay*gama);
        A03 = -1*(betaz*gama);

        //Elementos fora da diagonal
        A12 = (gama-1)*((betax*betay)/(beta*beta));
        A13 = (gama-1)*((betax*betaz)/(beta*beta));
        A23 = (gama-1)*((betay*betaz)/(beta*beta));

        //cout << gama << endl;

        //Elementos da diagonal


        A11 = (1+((gama-1)*((betax*betax)/(beta*beta))));
        A22 = (1+((gama-1)*((betay*betay)/(beta*beta))));
        A33 = (1+((gama-1)*((betaz*betaz)/(beta*beta))));
        }else
        {
        A11 = A22 = A33 = 1;
        A12 = A13 = A23 = 0;
        A01 = A02 = A03 = 0;

        }
        //Transformação de Lorentz.
        Double_t P0 = (A00*E1) + (A01*px) + (A02*py) + (A03*pz);              
        Double_t P1 = (A01*E1) + (A11*px) + (A12*py) + (A13*pz);
        Double_t P2 = (A02*E1) + (A12*px) + (A22*py) + (A23*pz);
        Double_t P3 = (A03*E1) + (A13*px) + (A23*py) + (A33*pz);


        //cout<<" Matriz de Transformação "<<endl;
        //cout<<" "<<A00<<"  "<<A01<<"  "<<A02<<"  "<<A03<<"  "<<endl;
        //cout<<" "<<A01<<"  "<<A11<<"  "<<A12<<"  "<<A13<<"  "<<endl;
        //cout<<" "<<A02<<"  "<<A12<<"  "<<A22<<"  "<<A23<<"  "<<endl;
        //cout<<" "<<A03<<"  "<<A13<<"  "<<A23<<"  "<<A33<<"  "<<endl;

        Double_t *vector = (Double_t*)malloc(4*sizeof(Double_t));  

        //retorna as variáveis transformadas.
        vector[0] = P0;
        vector[1] = P1;
        vector[2] = P2;
        vector[3] = P3;

        return vector;
        
    }


void Eventos_Todos_CBJ_LAB{

    #define N 20000

    //retirar a legenda estatística dos gráficos.
    gStyle->SetOptStat(000000);

    cout<<fixed;
    cout<<setprecision(10);

    //definição das variáveis.
    Double_t x[N], y[N], phi[N], theta[N], eta[N], PT[N], px[N], py[N], pz[N], E1[N], costheta[N];
    Double_t somaE=0, aux1=0, aux2=0,xcpe=0, ycpe=0, AnguloZenitalPPI,FatorC, h;
    int indice, j =0;

    // 82 eventos C-jatos.
    // altura H = 157 cm + 11.5 cm (metade do alvo de Carbono).
                                           
    Double_t H = 168.5; 
                                             
    int lNpts = readevento1("evento1517.txt",x,y,E1); FatorC =0.0073; AnguloZenitalPPI = atan(0.1860); (h = H/cos(AnguloZenitalPPI));

    //cálculo da conversão das medidas do evento.
    for(long i=0; i<lNpts; i++){  
        E1[i] = 1000*E1[i];
        somaE += E1[i]; // Energia total do evento em GeV.
        aux1 += x[i]*E1[i];
        aux2 += y[i]*E1[i];

    }

    //Coordenadas do centro ponderado de energia - CPE.
    xcpe = aux1/somaE;
    ycpe = aux2/somaE;

    for(long i=0; i<lNpts; i++){ 
        //As coordenadas no referencial do Centro Ponderado de Energia - CPE.
        x[i] = x[i] - xcpe;
        y[i] = y[i] - ycpe;

        x[i] = FatorC*x[i]*cos(AnguloZenitalPPI); // conversão para cm.
        y[i] = FatorC*y[i]*cos(AnguloZenitalPPI);

        theta[i]= anguloTheta(x[i], y[i], h); //ângulo Theta em radiano.
        eta[i] = MyEta(theta[i]);	//Pseudorapidity.

        phi[i] = atan2 (y[i],x[i]);

        PT[i] = E1[i]*sin(theta[i]); //momento transversal em GeV
        px[i] = PT[i]*cos(phi[i]);
        py[i] = PT[i]*sin(phi[i]);
        pz[i] = E1[i]*cos(theta[i]);



    }

    Write(x,y,eta,phi,E1,PT,lNpts,"Dados_de_todos_Eventos_LAB.txt"); //dados de posição com rotação, pseudorapidez e Energia no LAB.


    /*
lNpts = readevento1("evento1528.txt",x,y,E1);FatorC = 0.0061; AnguloZenitalPPI = atan(0.5700) ;  (h = H/cos(AnguloZenitalPPI)); 



lNpts= readevento1("evento1567.txt",x,y,E1); FatorC = 0.0117;  AnguloZenitalPPI = atan(0.1850);(h = H/cos(AnguloZenitalPPI)); 



lNpts= readevento1("evento156725.txt",x,y,E1); FatorC = 0.0072; AnguloZenitalPPI = atan(0.9310);(h = H/cos(AnguloZenitalPPI));




lNpts= readevento1("evento1576.txt",x,y,E1); FatorC = 0.006; AnguloZenitalPPI = atan(0.3000);(h = H/cos(AnguloZenitalPPI));   


lNpts= readevento1("evento1577.txt",x,y,E1); FatorC = 0.0061; AnguloZenitalPPI = atan(0.0000);(h = H/cos(AnguloZenitalPPI));  


lNpts= readevento1("evento1584.txt",x,y,E1); FatorC = 0.012; AnguloZenitalPPI = atan(0.3600);(h = H/cos(AnguloZenitalPPI)); 


lNpts= readevento1("evento1597.txt",x,y,E1); FatorC = 0.0044; AnguloZenitalPPI = atan(0.8020);  (h = H/cos(AnguloZenitalPPI)); 



lNpts= readevento1("evento15102.txt",x,y,E1); FatorC = 0.008; AnguloZenitalPPI = atan(0.5400);(h = H/cos(AnguloZenitalPPI)); 



lNpts= readevento1("evento15105.txt",x,y,E1); FatorC = 0.0176; AnguloZenitalPPI = atan(0.0000); (h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento15115.txt",x,y,E1);FatorC = 0.016; AnguloZenitalPPI = atan(0.5010);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento15150.txt",x,y,E1);FatorC = 0.0088; AnguloZenitalPPI = atan(0.7240);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento15156.txt",x,y,E1); FatorC = 0.004;  AnguloZenitalPPI = atan(0.0000); (h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento15159.txt",x,y,E1);FatorC = 0.004;  AnguloZenitalPPI = atan(0.0000); (h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento151614.txt",x,y,E1);FatorC = 0.0044; AnguloZenitalPPI = atan(0.8820);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento1680.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.6900); (h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento1685.txt",x,y,E1);FatorC = 0.0035; AnguloZenitalPPI = atan(0.1100);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento1686.txt",x,y,E1);FatorC = 0.0035; AnguloZenitalPPI = atan(0.7420);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento1691.txt",x,y,E1);FatorC = 0.0142; AnguloZenitalPPI = atan(0.4320);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento1696.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.1500);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento16101.txt",x,y,E1);FatorC = 0.0034; AnguloZenitalPPI = atan(0.1000);(h = H/cos(AnguloZenitalPPI)); 


lNpts= readevento1("evento16105.txt",x,y,E1);FatorC = 0.0142; AnguloZenitalPPI = atan(0.4110);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17192.txt",x,y,E1);FatorC = 0.003; AnguloZenitalPPI = atan(0.5960);(h = H/cos(AnguloZenitalPPI)); 


lNpts= readevento1("evento1769.txt",x,y,E1);FatorC = 0.0033; AnguloZenitalPPI = atan(0.0000);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17791.txt",x,y,E1);FatorC = 0.0033; AnguloZenitalPPI = atan(0.6510);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17792.txt",x,y,E1);FatorC = 0.0033; AnguloZenitalPPI = atan(0.2590); (h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17841.txt",x,y,E1);FatorC = 0.0072;  AnguloZenitalPPI = atan(0.2500);(h = H/cos(AnguloZenitalPPI)); 


lNpts= readevento1("evento17842.txt",x,y,E1);FatorC = 0.0074;  AnguloZenitalPPI = atan(0.9490);(h = H/cos(AnguloZenitalPPI)); 


lNpts= readevento1("evento1786.txt",x,y,E1);FatorC = 0.0072;   AnguloZenitalPPI = atan(0.4350);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento1789.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.9500);(h = H/cos(AnguloZenitalPPI)); 


lNpts= readevento1("evento1790.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.1670);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17961.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.7500);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17962.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.1000);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento171022.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.3700);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento171024.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.4620);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17104.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.2500);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17105.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.3000);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17115.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.4290);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17122.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.6150);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17124.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.8700);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17130.txt",x,y,E1);FatorC = 0.01;AnguloZenitalPPI = atan(0.1400);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17132.txt",x,y,E1);FatorC = 0.0036; AnguloZenitalPPI = atan(0.2080);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento171351.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.4900);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento171354.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.0000);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17136.txt",x,y,E1);FatorC = 0.0072;  AnguloZenitalPPI = atan(0.2270);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento171382.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.3830);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento171388.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.2000);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17140.txt",x,y,E1);FatorC = 0.0072;  AnguloZenitalPPI = atan(0.2220);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17148.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.5560);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento17150.txt",x,y,E1);FatorC = 0.0036;  AnguloZenitalPPI = atan(0.6450);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17159.txt",x,y,E1);FatorC = 0.0072;  AnguloZenitalPPI = atan(0.5830);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento17164.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.3330);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento1821.txt",x,y,E1);FatorC = 0.0036; AnguloZenitalPPI = atan(0.0000);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento1824.txt",x,y,E1);FatorC = 0.0066; AnguloZenitalPPI = atan(0.9090);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento1828.txt",x,y,E1);FatorC = 0.0033; AnguloZenitalPPI = atan(1.1700); (h = H/cos(AnguloZenitalPPI));




lNpts= readevento1("evento1830.txt",x,y,E1);FatorC = 0.0036;  AnguloZenitalPPI = atan(0.5500);(h = H/cos(AnguloZenitalPPI));




lNpts= readevento1("evento1832.txt",x,y,E1);FatorC = 0.0036; AnguloZenitalPPI = atan(0.5500);(h = H/cos(AnguloZenitalPPI));




lNpts= readevento1("evento1847.txt",x,y,E1);FatorC = 0.0066; AnguloZenitalPPI = atan(1.0000);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento1849.txt",x,y,E1);FatorC = 0.0066; AnguloZenitalPPI = atan(0.9040); (h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento1869.txt",x,y,E1);FatorC = 0.003;  AnguloZenitalPPI = atan(0.9040);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento187330.txt",x,y,E1);FatorC = 0.009; AnguloZenitalPPI = atan(0.0000);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento187650.txt",x,y,E1);FatorC = 0.009; AnguloZenitalPPI = atan(0.0000);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento1892.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.1700);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento1893.txt",x,y,E1);FatorC = 0.0072;AnguloZenitalPPI = atan(0.2000);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento18110.txt",x,y,E1);FatorC = 0.01;  AnguloZenitalPPI = atan(0.3100);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento18139.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.5150);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento18145.txt",x,y,E1);FatorC = 0.005;  AnguloZenitalPPI = atan(0.6670);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento18149.txt",x,y,E1);FatorC = 0.0023; AnguloZenitalPPI = atan(0.6670);(h = H/cos(AnguloZenitalPPI));




lNpts= readevento1("evento19100.txt",x,y,E1);FatorC = 0.005;  AnguloZenitalPPI = atan(0.0000);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento19105.txt",x,y,E1);FatorC = 0.0144; AnguloZenitalPPI = atan(0.1500);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento19107.txt",x,y,E1);FatorC = 0.005; AnguloZenitalPPI = atan(0.3600);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento19108.txt",x,y,E1);FatorC = 0.0072;  AnguloZenitalPPI = atan(0.5000);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento19115.txt",x,y,E1);FatorC = 0.01;  AnguloZenitalPPI = atan(0.5000);(h = H/cos(AnguloZenitalPPI)); 


lNpts= readevento1("evento191214.txt",x,y,E1);FatorC = 0.0072; AnguloZenitalPPI = atan(0.0000);(h = H/cos(AnguloZenitalPPI)); 



lNpts= readevento1("evento191215.txt",x,y,E1);FatorC = 0.005; AnguloZenitalPPI = atan(0.6000);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento19127.txt",x,y,E1);FatorC = 0.005;  AnguloZenitalPPI = atan(0.5000);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento19129.txt",x,y,E1);FatorC = 0.0064; AnguloZenitalPPI = atan(0.8400);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento191361.txt",x,y,E1);FatorC = 0.0064; AnguloZenitalPPI = atan(0.0000);(h = H/cos(AnguloZenitalPPI));


lNpts= readevento1("evento191362.txt",x,y,E1);FatorC = 0.0025; AnguloZenitalPPI = atan(0.3000);(h = H/cos(AnguloZenitalPPI));



lNpts= readevento1("evento19138.txt",x,y,E1);FatorC = 0.0025; AnguloZenitalPPI = atan(0.000);(h = H/cos(AnguloZenitalPPI));





*/

}
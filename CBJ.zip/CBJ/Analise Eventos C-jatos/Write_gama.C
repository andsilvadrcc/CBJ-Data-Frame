//
// Write_gama.C
// ---------------------------------------------------------------------------
// Esta função escreve um arquivo txt de saída, com 1 coluna com valores do fator de Lorentz.
// ---------------------------------------------------------------------------

void Write_gama(Double_t *GAMA,  int NLoops, const char *filename){

  FILE *fout;
  fout = fopen(filename,"a");
  for (int i=0;i<NLoops;i++){
    fprintf(fout,"%.6f \n", GAMA[i]);
  }
  fclose(fout);  
  //cout<<"Foi Salvo um arquivo txt de nome: "<<filename<<endl;
}

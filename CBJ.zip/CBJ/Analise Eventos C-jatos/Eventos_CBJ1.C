#include "TCanvas.h"
#include "TStyle.h"
#include "TH1.h"
#include "TGaxis.h"
#include "TLatex.h"
#include "TROOT.h"
#include "TGraphErrors.h"
#include "TF1.h"
#include "TLegend.h"
#include "TArrow.h"
#include <math.h>
#include "readevento2.C"
#include "WriteTxt.C"
#include "TFile.h"
#include "TTree.h"

// https://github.com/andsilvadrcc/CBJ-Data-Frame  Everything!!!


//gStyle->SetOptStat(000000); //NOT put subtitles on the graphics.
    

//  Transformacao de Lorentz (geral em todas as direcoes)...

Double_t* BOOST(Double_t betax,Double_t betay,Double_t betaz,
                Double_t px,Double_t py,Double_t pz,Double_t E1){
     
    //Array Elements of the matrix of Lorentz:
    Double_t A00, A11, A22, A33, A01, A02, A03, A12, A13, A23, beta;

    //Speed Parameter
    beta = sqrt(pow(betax,2.0)+pow(betay,2.0)+pow(betaz,2.0));
        
    // Lorentz Factor.
    Double_t gama = pow(1-pow(beta,2),-0.5);
        
   //gama:
   A00 = gama;
   if(beta !=0){
      //Symmetrical elements of the matrix:
      A01 = -1*(betax*gama);
      A02 = -1*(betay*gama);
      A03 = -1*(betaz*gama);

      //Elements outside the diagonal:
      A12 = (gama-1)*((betax*betay)/(beta*beta));
      A13 = (gama-1)*((betax*betaz)/(beta*beta));
      A23 = (gama-1)*((betay*betaz)/(beta*beta));


      //Elements of the diagonal:
      A11 = (1+((gama-1)*((betax*betax)/(beta*beta))));
      A22 = (1+((gama-1)*((betay*betay)/(beta*beta))));
      A33 = (1+((gama-1)*((betaz*betaz)/(beta*beta))));
    }else{
      //Elements of the identity matrix:
      A11 = A22 = A33 = 1;
      A12 = A13 = A23 = 0;
      A01 = A02 = A03 = 0;
            
    }
        
    //Lorentz Transformation:
        
    Double_t P0 = (A00*E1) + (A01*px) + (A02*py) + (A03*pz);              
    Double_t P1 = (A01*E1) + (A11*px) + (A12*py) + (A13*pz);
    Double_t P2 = (A02*E1) + (A12*px) + (A22*py) + (A23*pz);
    Double_t P3 = (A03*E1) + (A13*px) + (A23*py) + (A33*pz);
        
    //cout<<" Matriz de Transformação "<<endl;
    //cout<<" "<<A00<<"  "<<A01<<"  "<<A02<<"  "<<A03<<"  "<<endl;
    //cout<<" "<<A01<<"  "<<A11<<"  "<<A12<<"  "<<A13<<"  "<<endl;
    //cout<<" "<<A02<<"  "<<A12<<"  "<<A22<<"  "<<A23<<"  "<<endl;
    //cout<<" "<<A03<<"  "<<A13<<"  "<<A23<<"  "<<A33<<"  "<<endl;
        
    Double_t *vector = (Double_t*)malloc(4*sizeof(Double_t));  

    //return the 4-vector (E,px,py,pz) = (P0,P1,P2,P3).
    vector[0] = P0;
    vector[1] = P1;
    vector[2] = P2;
    vector[3] = P3;

    //return pointer
    return vector;
    }

    // **************************************************************

    // Let's begin the function here!
    void Eventos_CBJ1(const char* fileNameIn="softQCD.root"){
    
    // histogram statistics box can be selected
    gStyle->SetOptStat(111); 
        
    // vector size
    Int_t N = 100000; 
    
    //Precision:
    cout<<fixed;
    cout<<setprecision(15);
    
    // Open the file that have the object Tree
    TFile *fin = new TFile(fileNameIn,"READ");
        
    // Take the objects TTree that be inside of the file .root
    TTree *T = (TTree*)fin->Get("T");
    TTree *T1 = (TTree*)fin->Get("T1");

    //definition  of variables
    Double_t x[N], y[N], eta[N], phi[N], E1[N], PT[N], PX[N], PY[N];
    Double_t PZ[N], theta[N],GAMA[0], Ecut, InvariantMass,P;
    Double_t *vector, en, Px, Py, Pz, somapz =0, somaE=0,somaE1=0;
    Double_t somae=0, Theta, pseudorapidity, norm = 1, scale;
    int id, Nparticles, cont=0, l, Np=0;
    
    
    Double_t px, py, pz, pt, e, Eta, Phi, gama;
    Double_t Gama, beta, bx, by, bz, Bx, By, Bz, ETA, rapidity;
    
    // Access the Branch of the TTree "T"
    T->SetBranchAddress("px",&px);
    T->SetBranchAddress("py",&py);
    T->SetBranchAddress("pz",&pz);
    T->SetBranchAddress("pt",&pt);
    T->SetBranchAddress("e",&e);
    T->SetBranchAddress("id",&id);
    T->SetBranchAddress("Eta",&Eta);
    T->SetBranchAddress("Phi",&Phi);

    // Access the Branch of the TTree "T1"
    T1->SetBranchAddress("gama",&gama);
    T1->SetBranchAddress("bx",&bx);
    T1->SetBranchAddress("by",&by);
    T1->SetBranchAddress("bz",&bz);
    T1->SetBranchAddress("Nparticles",&Nparticles);
    
    // From PYTHIA the number of events and 
    // the number of the particles.
    Int_t nentries = (Int_t)T->GetEntries();
    Int_t nevents = (Int_t)T1->GetEntries();
    
    cout << "nentries=" << nentries << endl;
    
    // 82 Events "C-jets" with 1334 showers in the frame LAB.
    int lNpts = readevento2("Dados_de_todos_Eventos_LAB.txt",
    x,y,eta,phi,E1,PT); // Energy GeV.
    
    THStack *hs = new THStack("hs","Histograms");
    
    //LAB Frame
    // create one histogram
    TH1F *hist1 = new TH1F("hist1","Multiplicity LAB",100,0,20);//CBJ
    TH1F *hist2 = new TH1F("hist2","",100,0,20); // pythia
    
    //Energy Distribution
    TH1F *hist3 = new TH1F("hist3","Energy Distribution LAB",
    100,0,20); //CBJ
    TH1F *hist4 = new TH1F("hist4","",100,0,20); //pythia
    
    // CBJ data Fill the histograms in the LAB Frame:
    for (Int_t i=0; i<lNpts; i++) {
        
        theta[i] = 2*TMath::ATan(TMath::Exp(-eta[i]));
        PX[i] = PT[i]*cos(phi[i]);
        PY[i] = PT[i]*sin(phi[i]);
        PZ[i] = E1[i]*cos(theta[i]);
             
        //Sum E and pz:
        somaE = somaE + E1[i];
        somapz = somapz + PZ[i];
        
        hist1->Fill(eta[i]); // CBJ Data Multiplicity
        hist3->Fill(eta[i],E1[i]); // CBJ Data Energy Distribution
        
    }
    somapz =0;
    
    // PYTHIA in the LAB Frame:
    for(Int_t i=0; i<nentries; i++) {
        
        T->GetEntry(i);
        
     	if(id == 22 || id == 211 || id == -211 ){
    
        	hist2->Fill(Eta); // From PYTHIA with Energy cut
        	hist4->Fill(Eta,e); // From PYTHIA with Energy cut
        	cont++;
        
        	somapz = somapz + pz;
    
      	}
    }
    
    somapz =0;
    
    // **************************************************************
    
    // 82 Events "C-jets" with 1334 showers in the frame CM.
    lNpts = readevento2("Dados_de_todos_Eventos_CM.txt",x,y,
    eta,phi,E1,PT); // Energy GeV.
    
    //CM Frame 
    // create one histogram
    TH1F *hist5 = new TH1F("hist5","Multiplicity CM",100,-10,10);
    TH1F *hist6 = new TH1F("hist6","",100,-10,10);
    
    //Energy Distribution
    TH1F *hist7 = new TH1F("hist7","Energy Distribution CM",
    100,-10,10);
    TH1F *hist8 = new TH1F("hist8","",100,-10,10);
    
    // CBJ data:
    for (Int_t i=0; i<lNpts; i++) {
        
        theta[i] = 2*TMath::ATan(TMath::Exp(-eta[i]));
        PX[i] = PT[i]*cos(phi[i]);
        PY[i] = PT[i]*sin(phi[i]);
        PZ[i] = E1[i]*cos(theta[i]); 
        
        //Sum E and pz:
        somaE1 = somaE1 + E1[i];
        somapz = somapz + PZ[i];
        
        hist5->Fill(eta[i]); // CBJ Data Multiplicity
        hist7->Fill(eta[i],E1[i]); // CBJ Data Energy Distribution
 
    }
    
    cout << "CM(CBJ):" << somapz << endl;
    
    somapz =0;
    
    // **************************************************************
    
    l = 0;
    Double_t somaen=0;
    
      // PYTHIA pp:
        
      for(Int_t i=0; i<nevents; i++) {

          T1->GetEntry(i);
          Bx = bx;
          By = by;
          Bz = bz;
          Np = Np + Nparticles;
            
          gama = pow(1-(Bz*Bz),-0.5);
          //cout << i << " bz = "<< Bz <<" gama = "<< gama << endl;
            
          for(Int_t j=l; j<Np; j++) {
            
            T->GetEntry(j);
               if(id == 22 || id == 211 || id == -211 ){

               //Lorentz Transformation
               vector = BOOST(Bx, By, Bz, px, py, pz, e);
               
               //The return of the BOOST:
               en = vector[0];
               Px = vector[1];
               Py = vector[2];          
               Pz = vector[3];
                
               // Sum momentum in the CM frame:
               somapz = somapz + Pz;
                
               //Angle in the CM frame:
               Theta = atan2(pt,Pz);

	       //pseudo-rapidity.
               ETA = -1*log(tan(Theta/2)); 
				
	       // Fill the Histograms multiplicity 
	       //and Energy distribution
               hist6->Fill(ETA);
               hist8->Fill(ETA, en);
                
               somae = somae + e;
               somaen = somaen + en;
             
               }
               l = Np;
            }
        }
        
        cout << "CM(pythia):" << somapz << endl;
        
        somapz = 0;
    
    // ****************Compare histograms****************************
    
    TCanvas *c1 = new TCanvas("c1","Histograms",10,10,3000,3000);

    // one TCanvas divide in four parts:
    c1->Divide(2,2);
    // The first histogram:
    c1->cd(1);
    c1->cd(1)->SetGridx();    // Horizontal grid
    c1->cd(1)->SetGridy();    // Vertical grid
    c1->cd(1)->SetLogy(1);

    //normalize histogram
    scale = norm/(lNpts);
    hist1->Scale(scale);
    
    // Chi2 Test ...
    //Double_t res[100];
    //hist1->Chi2Test(hist2,"UW P",res);
    
    hist1->SetLineColor(kBlack);
    hist1->GetYaxis()->SetTitle("dN/d#eta");
    hist1->GetXaxis()->SetTitle("#eta");
    hist1->GetXaxis()->CenterTitle();
    hist1->GetYaxis()->CenterTitle();
    hist1->SetMaximum(1);
    
    hist1->GetYaxis()->SetTitleSize(30);
    hist1->GetYaxis()->SetTitleFont(43);
    hist1->GetYaxis()->SetTitleOffset(1.4);
    hist1->GetYaxis()->SetLabelFont(43);// font size in pixel
    hist1->GetYaxis()->SetLabelSize(20);
    
    hist1->GetXaxis()->SetTitleSize(30);
    hist1->GetXaxis()->SetTitleFont(43);
    hist1->GetXaxis()->SetTitleOffset(1.5);
    hist1->GetXaxis()->SetLabelFont(43); // Absolute font size
    hist1->GetXaxis()->SetLabelSize(20);
    
    hs->Add(hist1);
    hist1->SetFillStyle(1);
    hist1->SetMarkerStyle(8);
    hist1->SetMarkerSize(1);
    hist1->SetMarkerColor(1);
    hist1->Draw("phistE1");
    
    //normalize histogram
    scale = norm/(cont);
    hist2->Scale(scale);
    
    hist2->SetLineColor(kRed);
    hist2->SetFillStyle(3001);
    hist2->SetLineWidth(2);
    hist2->SetLineStyle(1);
    hs->Add(hist2);
    hist2->Draw("histsame");
    
    // draw the legend
    TLegend *legend1a=new TLegend(0.7,0.7,0.9,0.8);
    legend1a->SetTextFont(72);
    legend1a->SetTextSize(0.04);
    legend1a->AddEntry(hist1,"CBJ Data","lpe");
    legend1a->Draw();

    // draw the legend
    TLegend *legend2a=new TLegend(0.1,0.8,0.5,0.9);
    legend2a->SetTextFont(72);
    legend2a->SetTextSize(0.04);
    legend2a->AddEntry(hist2,"PYTHIA 8 (pp) softQCD: E_{cut}","lpe");
    legend2a->Draw();
    
    c1->cd(2);
    c1->cd(2)->SetGridx();    // Horizontal grid
    c1->cd(2)->SetGridy();    // Vertical grid
    c1->cd(2)->SetLogy(1);
    
    //normalize histogram
    scale = norm/(somaE);
    hist3->Scale(scale);
    
    hist3->SetLineColor(kBlack);
    hist3->GetYaxis()->SetTitle("dE/d#eta");
    hist3->GetXaxis()->SetTitle("#eta");
    hist3->GetXaxis()->CenterTitle();
    hist3->GetYaxis()->CenterTitle();
    hist3->SetMaximum(1);
    
    hist3->GetYaxis()->SetTitleSize(30);
    hist3->GetYaxis()->SetTitleFont(43);
    hist3->GetYaxis()->SetTitleOffset(1.4);
    hist3->GetYaxis()->SetLabelFont(43); // Absolute font size
    hist3->GetYaxis()->SetLabelSize(20);
    
    hist3->GetXaxis()->SetTitleSize(30);
    hist3->GetXaxis()->SetTitleFont(43);
    hist3->GetXaxis()->SetTitleOffset(1.5);
    hist3->GetXaxis()->SetLabelFont(43); // Absolute font size
    hist3->GetXaxis()->SetLabelSize(20);
    
    hs->Add(hist3);
    hist3->SetFillStyle(1);
    hist3->SetMarkerStyle(8);
    hist3->SetMarkerSize(1);
    hist3->SetMarkerColor(1);
    hist3->Draw("phistE1");
    
    //normalize histogram
    scale = norm/(somae);
    hist4->Scale(scale);
    
    hist4->SetLineColor(kRed);
    hist4->SetFillStyle(3001);
    hist4->SetLineWidth(2);
    hist4->SetLineStyle(1);
    hs->Add(hist4);
    hist4->Draw("histsame");

    // draw the legend
    TLegend *legend4a=new TLegend(0.7,0.7,0.9,0.8);
    legend4a->SetTextFont(72);
    legend4a->SetTextSize(0.04);
    legend4a->AddEntry(hist3,"CBJ Data","lpe");
    legend4a->Draw();

    // draw the legend
    TLegend *legend5a=new TLegend(0.1,0.8,0.5,0.9);
    legend5a->SetTextFont(72);
    legend5a->SetTextSize(0.04);
    legend5a->AddEntry(hist4,"PYTHIA 8 (pp) softQCD: E_{cut}","lpe");
    legend5a->Draw();

    c1->cd(3);
    c1->cd(3)->SetGridx();    // Horizontal grid
    c1->cd(3)->SetGridy();    // Vertical grid
    c1->cd(3)->SetLogy(1);

    //normalize histogram
    scale = norm/(lNpts);
    hist5->Scale(scale);
    
    hist5->SetLineColor(kBlack);
    //hist5->SetTitle("Multiplicity CM");
    hist5->GetYaxis()->SetTitle("dN/d#eta");
    hist5->GetXaxis()->SetTitle("#eta");
    hist5->GetXaxis()->CenterTitle();
    hist5->GetYaxis()->CenterTitle();
    hist5->SetMaximum(1);
    
    hist5->GetYaxis()->SetTitleSize(30);
    hist5->GetYaxis()->SetTitleFont(43);
    hist5->GetYaxis()->SetTitleOffset(1.4);
    hist5->GetYaxis()->SetLabelFont(43); // Absolute font size
    hist5->GetYaxis()->SetLabelSize(20);
    
    hist5->GetXaxis()->SetTitleSize(30);
    hist5->GetXaxis()->SetTitleFont(43);
    hist5->GetXaxis()->SetTitleOffset(1.5);
    hist5->GetXaxis()->SetLabelFont(43); // Absolute font size
    hist5->GetXaxis()->SetLabelSize(20);
    
    hs->Add(hist5);
    hist5->SetFillStyle(1);
    hist5->SetMarkerStyle(8);
    hist5->SetMarkerSize(1);
    hist5->SetMarkerColor(1);
    hist5->Draw("phistE1");
    
    //c1->Update();
    
    //normalize histogram
    //cout << hist2->Integral()  << endl;
    scale = norm/(cont);
    hist6->Scale(scale);

    hist6->SetLineColor(kRed);
    hist6->SetFillStyle(3001);
    hist6->SetLineWidth(2);
    hist6->SetLineStyle(1);
    hs->Add(hist6);
    hist6->Draw("histsame");
    
    // draw the legend
    TLegend *legend7a=new TLegend(0.7,0.7,0.9,0.8);
    legend7a->SetTextFont(72);
    legend7a->SetTextSize(0.04);
    legend7a->AddEntry(hist5,"CBJ Data","lpe");
    legend7a->Draw();

    // draw the legend
    TLegend *legend8a=new TLegend(0.1,0.8,0.5,0.9);
    legend8a->SetTextFont(72);
    legend8a->SetTextSize(0.04);
    legend8a->AddEntry(hist6,"PYTHIA 8 (pp) softQCD: E_{cut}","lpe");
    legend8a->Draw();

    c1->cd(4);
    c1->cd(4)->SetGridx();    // Horizontal grid
    c1->cd(4)->SetGridy();    // Vertical grid
    c1->cd(4)->SetLogy(1);
    
    //normalize histogram
    scale = norm/(somaE1);
    hist7->Scale(scale);
    
    hist7->SetLineColor(kBlack);
    hist7->GetYaxis()->SetTitle("dE/d#eta");
    hist7->GetXaxis()->SetTitle("#eta");
    hist7->GetXaxis()->CenterTitle();
    hist7->GetYaxis()->CenterTitle();
    hist7->SetMaximum(1);
    
    hist7->GetYaxis()->SetTitleSize(30);
    hist7->GetYaxis()->SetTitleFont(43);
    hist7->GetYaxis()->SetTitleOffset(1.4);
    hist7->GetYaxis()->SetLabelFont(43); // Absolute font size
    hist7->GetYaxis()->SetLabelSize(20);
    
    hist7->GetXaxis()->SetTitleSize(30);
    hist7->GetXaxis()->SetTitleFont(43);
    hist7->GetXaxis()->SetTitleOffset(1.5);
    hist7->GetXaxis()->SetLabelFont(43); // Absolute font size
    hist7->GetXaxis()->SetLabelSize(20);
    
    hs->Add(hist7);
    hist7->SetFillStyle(1);
    hist7->SetMarkerStyle(8);
    hist7->SetMarkerSize(1);
    hist7->SetMarkerColor(1);
    hist7->Draw("phistE1");
    
    // normalize histogram
    scale = norm/(somaen);
    
    //cout << " somaen = " << somaen << endl;
    
    hist8->Scale(scale);
    
    hist8->SetLineColor(kRed);
    hist8->SetFillStyle(3001);
    hist8->SetLineWidth(2);
    hist8->SetLineStyle(1);
    hs->Add(hist8);
    hist8->Draw("histsame");
    
    // draw the legend
    TLegend *legend10a=new TLegend(0.7,0.7,0.9,0.8);
    legend10a->SetTextFont(72);
    legend10a->SetTextSize(0.04);
    legend10a->AddEntry(hist7,"CBJ Data","lpe");
    legend10a->Draw();

    // draw the legend
    TLegend *legend11a=new TLegend(0.1,0.8,0.5,0.9);
    legend11a->SetTextFont(72);
    legend11a->SetTextSize(0.04);
    legend11a->AddEntry(hist8,"PYTHIA 8 (pp) softQCD: E_{cut}","lpe");
    legend11a->Draw();
    
    // Save the Canvas in .png:
    c1->SaveAs("Graph_EQD/PYTHIA/pythia_pp.png");

    }

//
// Readevento1.C
// Esta macro lê um arquivo txt
// e coloca nos arrays internos x e y
//


int readevento1(const char , Double_t , Double_t , Double_t );



int readevento1(const char *fileNameIn, Double_t *x, Double_t *y, Double_t *E)
{
  int i=0;
  ifstream fileIn(fileNameIn); //arquivo com os dados 
  if(!fileIn){
    cout<<"Could NOT Find File: "<<fileNameIn<<endl;
   return 0;  
}
  while ((fileIn >> x[i] >> y[i] >> E[i])) i++;
  if(i==0){ cout << "Nenhuma linha foi lida!!!"<<endl;} 
  else{cout << "Foram lidos 3 colunas, posicao x, y e energia E com " <<i<< " linhas do arquivo " <<fileNameIn<<endl;}
return i;
	

}


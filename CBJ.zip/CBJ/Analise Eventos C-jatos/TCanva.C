

void TCanva() {

TCanvas *c1 = new TCanvas("c1","c1");

TH1D *h1 = new TH1D("h1","h1",500,-5,5);
h1->FillRandom("gaus");

TH1D *h2 = new TH1D("h2","h2",500,-5,5);
h2->FillRandom("gaus");

h1->Draw();
h2->Draw("same");

}
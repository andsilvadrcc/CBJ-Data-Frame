#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TBrowser.h"
#include "TH1.h"
#include "TH1F.h"
#include "TH2.h"
#include "TRandom.h"
#include "TMath.h"
#include <iostream>
#include <string> 


#include "read.C"

void hist_energy_cjets(){

    
Double_t E1[100];
    
int N = read("Energy_C-jets_Events.txt", E1);

    TCanvas *c1 = new TCanvas("c1","Histograms ",10,10,3000,3000);
    
    
    TH1F *hist1 = new TH1F("hist1","Energy Distribution C-jets",100,10,300); // CBJ
    
    for(int i=0; i<N; i++){
        
        hist1->Fill(3*E1[i]/1000); // CBJ Data Energy Distribution
    
    }

    // The first histogram:
    c1->cd(1);
    c1->cd(1)->SetGridx();    // Horizontal grid
    c1->cd(1)->SetGridy();    // Vertical grid
    c1->cd(1)->SetLogy(1);

    hist1->SetLineColor(kBlack);
    hist1->GetYaxis()->SetTitle("N");
    hist1->GetXaxis()->SetTitle("Energy C Jets [TeV]");
    hist1->GetXaxis()->CenterTitle();
    hist1->GetYaxis()->CenterTitle();
    
    hist1->GetYaxis()->SetTitleSize(30);
    hist1->GetYaxis()->SetTitleFont(43);
    hist1->GetYaxis()->SetTitleOffset(1.4);
    hist1->GetYaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
    hist1->GetYaxis()->SetLabelSize(25);
    
    hist1->GetXaxis()->SetTitleSize(30);
    hist1->GetXaxis()->SetTitleFont(43);
    hist1->GetXaxis()->SetTitleOffset(1.5);
    hist1->GetXaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
    hist1->GetXaxis()->SetLabelSize(25);
    
    hist1->SetFillStyle(1);
    hist1->SetMarkerStyle(8);
    hist1->SetMarkerSize(1);
    hist1->SetMarkerColor(1);
    hist1->Draw();



}
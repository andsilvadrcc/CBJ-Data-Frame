
#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TBrowser.h"
#include "TH1.h"
#include "TH1F.h"
#include "TH2.h"
#include "TRandom.h"
#include "TMath.h"

using namespace std;

using namespace ROOT::Experimental::VecOps;

#include <iostream>
#include <string>
#include <vector>
#include <iterator>


    void Analysis_EPOS_LHC(){
        

      //ROOT::Experimental::TDataFrame d("Particle","crmc_eposlhc_374415082_p_C_617.root");
      //ROOT::Experimental::TDataFrame d("Particle","crmc_eposlhc_363392560_p_C_80000.root");
      ROOT::Experimental::TDataFrame d("Particle","crmc_eposlhc_112108849_p_C_130000.root");
      //ROOT::Experimental::TDataFrame d("Particle","crmc_eposlhc_888297222_p_p_3500.root");
        
        std::vector<double> v;
        using doubles = TVec<double>;
        
        auto ptCalc = [&v](doubles pxs, doubles pys) {
            v.clear(); 
            for (unsigned int i=0;i < pxs.size(); ++i) v.emplace_back(sqrt(pxs[i]*pxs[i] + pys[i]*pys[i]));
            return v;};
            
            auto cut = [](double E) {return E > 200.;};
            auto dd = d.Define("pt", ptCalc, {"px", "py"});
            auto hpt = dd.Filter(cut,{"E"}).Histo1D({"hpt", "p_{T} distribution", 100, 0, 15}, "pt");
        
            

            //drawing
            auto c1 = new TCanvas("c1", "c1", 10, 10, 700, 500);
            c1->SetGrid(1,1);
            c1->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
            c1->SetLogy(1);
            hpt->GetYaxis()->SetTitle("dN/dp_{T} [GeV^{-1}]");
            hpt->GetXaxis()->SetTitle("p_{T} [GeV]");
            hpt->DrawClone();
        
        
        // ***********************************************************************************
        std::vector<double> v1;
        using doubles = TVec<double>;

        auto RapidityCalc = [&v1](doubles Es, doubles pzs) {
        v1. clear(); 
        for (unsigned int i=0;i < Es.size(); ++i) v1.emplace_back(0.5*log((Es[i]+pzs[i])/(Es[i]-pzs[i])));
        return v1;};

        
        auto dd1 = d.Define("y", RapidityCalc, {"E", "pz"});
        auto histoy = dd1.Histo1D({"histoy", "rapidity distribution", 100, -15, 15}, "y");
        
            

            //drawing
            auto c2 = new TCanvas("c2", "c2", 10, 10, 700, 500);
            c2->SetGrid(1,1);
            c2->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
            c2->SetLogy(1);
            histoy->GetYaxis()->SetTitle("dN/dy");
            histoy->GetXaxis()->SetTitle("y");
            histoy->DrawClone();
       
      // ***********************************************************************************
            std::vector<double> v2;
            using doubles = TVec<double>;
            
            auto RapCalc = [&v2](doubles Es, doubles pzs) {
                v2. clear(); 
                for (unsigned int i=0;i < Es.size(); ++i) v2.emplace_back(0.5*log((Es[i]+pzs[i])/(Es[i]-pzs[i])));
                return v2;};
                
                auto dd2 = d.Define("rap", RapCalc, {"E", "pz"});
                auto histoy1 = dd2.Histo1D({"histoy1", "Energy distribution in rapidity", 100, -15, 15}, "rap", "E");
                
                //drawing
                auto c3 = new TCanvas("c3", "c3", 10, 10, 700, 500);
                c3->SetGrid(1,1);
                c3->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
                c3->SetLogy(1);
                histoy1->GetYaxis()->SetTitle("dE/dy [GeV]");
                histoy1->GetXaxis()->SetTitle("y");
                histoy1->DrawClone();
                
        // ***********************************************************************************
                
            
                auto c4 = new TCanvas("c4", "c4", 10, 10, 700, 500);
                c3->SetGrid(1,1);
                c3->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
                c3->SetLogy(1);
                
                auto myHisto = d.Histo1D({"myHisto", "Multiplicity of Particles", 100, -400, 400}, "pdgid");
                myHisto->GetYaxis()->SetTitle("Multiplicity");
                myHisto->GetXaxis()->SetTitle("PDGid");
                myHisto->DrawClone();
            
            
            

    
    }

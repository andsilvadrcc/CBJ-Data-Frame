    // *******************************************************
    // Create  a window for show the graphic
    // *******************************************************
    TCanvas *c6 = new TCanvas("c6","c6",10,10,700,500);
    //c6->SetFillColor(18);
    c6->SetGrid(1,1);
    c6->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
    c6->SetLogy(1);


    // create one histograms
    TH1F *hpt= new TH1F("hpt","pt distribution",100,0,3);

    //Fill the histogram
    for (Int_t i=0; i<lNpts; i++) {
        hpt->Fill(PT[i]); 

    }
    //Draw the histogram
    hpt->Draw();
    hpt->GetYaxis()->SetTitle("dN/dp_{T} [GeV^{-1}]");
    hpt->GetXaxis()->SetTitle("p_{T} [GeV]");
    
    cout << " soma pz = " << somapz << endl;
    cout << "eta media = " << TMath::ATanH(beta) << endl;
//
// Readevento2.C
// Esta macro lê um arquivo txt
// e coloca nos arrays internos 
//


int readevento2(const char , Double_t , Double_t , Double_t, Double_t, Double_t, Double_t );



int readevento2(const char *fileNameIn, Double_t *x, Double_t *y, Double_t *eta, Double_t *phi, Double_t *E1, Double_t *PT)
{
  int i=0;
  ifstream fileIn(fileNameIn); //arquivo com os dados 
  if(!fileIn){
    cout<<"Could NOT Find File: "<<fileNameIn<<endl;
   return 0;  
}
  while ((fileIn >> x[i] >> y[i] >> eta[i] >> phi[i] >> E1[i]>> PT[i])) i++;
  if(i==0){ cout << "Nenhuma linha foi lida!!!"<<endl;} 
  else{cout << "Foram lidos 6 colunas " <<i<< " linhas do arquivo " <<fileNameIn<<endl;}
return i;
	

}


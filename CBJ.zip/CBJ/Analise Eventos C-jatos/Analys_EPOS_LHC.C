
#include <ROOT/TDataFrame.hxx>
#include <TCanvas.h>
#include <TApplication.h>

using namespace std;

using namespace ROOT::Experimental;
using namespace ROOT::Experimental::VecOps;


    void Analys_EPOS_LHC(){
        

      TDataFrame d("Particle","crmc_eposlhc_112108849_p_C_130000.root");
      TDataFrame d1("T","Dados_de_todos_Eventos_LAB.root");
      TDataFrame d2("T1","Dados_de_todos_Eventos_CM.root");

        // TVec supports per-element operations (a-la numpy) and simple filtering with v[v > 3]
      
        using doubles = TVec<double>;
        
        auto cutPt = [](doubles pxs, doubles pys, doubles Es) {
            auto all_pts = sqrt(pxs*pxs + pys*pys);
            auto good_pts = all_pts[Es > 200.];
            return good_pts;
        };

        auto hpt = d.Define("pt", cutPt, {"px", "py", "E"}).Histo1D({"hpt", "p_{T} distribution", 100, 0, 15}, "pt");
            
            //auto hpt1 = d1.Histo1D("pt");
        
            

            //drawing
            auto c1 = new TCanvas("c1", "c1", 10, 10, 700, 500);
            c1->SetGrid(1,1);
            c1->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
            c1->SetLogy(1);
            
            hpt->GetYaxis()->SetTitle("dN/dp_{T} [GeV^{-1}]");
            hpt->GetXaxis()->SetTitle("p_{T} [GeV]");
            hpt->DrawClone();
            //hpt1->SetLineColor(kRed);
            //hpt1->DrawClone("same");
        
        /*
        // ***********************************************************************************
        std::vector<double> v1;
        using doubles = TVec<double>;

        auto RapidityCalc = [&v1](doubles Es, doubles pzs) {
        v1. clear(); 
        for (unsigned int i=0;i < Es.size(); ++i) v1.emplace_back(0.5*log((Es[i]+pzs[i])/(Es[i]-pzs[i])));
        return v1;};

        
        auto dd1 = d.Define("y", RapidityCalc, {"E", "pz"});
        auto histoy = dd1.Histo1D({"histoy", "rapidity distribution", 100, -15, 15}, "y");
        
        auto histoy12 = d1.Histo1D("Eta");
            

            //drawing
            auto c2 = new TCanvas("c2", "c2", 10, 10, 700, 500);
            c2->SetGrid(1,1);
            c2->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
            c2->SetLogy(1);
            histoy->GetYaxis()->SetTitle("dN/dy");
            histoy->GetXaxis()->SetTitle("y");
            histoy->DrawClone();
            histoy12->SetLineColor(kRed);
            histoy12->DrawClone("same");
       
      // ***********************************************************************************
            std::vector<double> v2;
            using doubles = TVec<double>;
            
            auto RapCalc = [&v2](doubles Es, doubles pzs) {
                v2. clear(); 
                for (unsigned int i=0;i < Es.size(); ++i) v2.emplace_back(0.5*log((Es[i]+pzs[i])/(Es[i]-pzs[i])));
                return v2;};
                
                auto dd2 = d.Define("rap", RapCalc, {"E", "pz"});
                
                auto histoy1 = dd2.Histo1D({"histoy1", "Energy distribution in rapidity", 100, -15, 15}, "rap", "E");
                
                auto histoy3 = d1.Histo1D({"histoy3", "Energy distribution in rapidity", 100, -15, 15}, "Eta", "e");
                
                //drawing
                auto c3 = new TCanvas("c3", "c3", 10, 10, 700, 500);
                c3->SetGrid(1,1);
                c3->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
                c3->SetLogy(1);
                histoy1->GetYaxis()->SetTitle("dE/dy [GeV]");
                histoy1->GetXaxis()->SetTitle("y");
                histoy1->DrawClone();
                histoy3->SetLineColor(kRed);
                histoy3->DrawClone("same");
                
        // ***********************************************************************************
                
            
                auto c4 = new TCanvas("c4", "c4", 10, 10, 700, 500);
                c3->SetGrid(1,1);
                c3->SetLogx(0); // 0 == scale without Log, 1 == scale with Log
                c3->SetLogy(1);
                
                auto myHisto = d.Histo1D({"myHisto", "Multiplicity of Particles", 100, -400, 400}, "pdgid");
                myHisto->GetYaxis()->SetTitle("Multiplicity");
                myHisto->GetXaxis()->SetTitle("PDGid");
                myHisto->DrawClone();
            
            
            

    */
    }
    
    int main(){
        TApplication app("app", nullptr, nullptr);
        Analysis_EPOS_LHC();
        app.Run();
    return 0;
    }

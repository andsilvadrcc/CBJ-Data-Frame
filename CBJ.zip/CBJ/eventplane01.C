
#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TBrowser.h"
#include "TH1.h"
#include "TH1F.h"
#include "TH2.h"
#include "TRandom.h"
#include "TMath.h"
#include <iostream>
#include <string> 

void eventplane01(Double_t adhocrot = 0.0) {
    //Code to demonstrate algorithm for symmetry plane determination
    const long lNpts = 10000;
    gStyle->SetOptStat(0); 
    Double_t x[lNpts], y[lNpts], phi[lNpts];

    TF1 *fx = new TF1("fx","TMath::Gaus(x,[0],[1])",-10,10); 
    TF1 *fy = new TF1("fy","TMath::Gaus(x,[0],[1])",-10,10); 
    
    fx->SetParameter(0,0); 
    fx->SetParameter(1,1); 
    fy->SetParameter(0,0); 
    fy->SetParameter(1,2); 
    
    gRandom->SetSeed(222); 
    
    TH1D *hphis = new TH1D("hphis","",100,-TMath::Pi(),TMath::Pi() ) ; 
    
    Double_t xt, yt; 
    
    cout<<"Generating points..."<<endl;
    for( long i=0; i<lNpts; i++){ 
      xt = fx->GetRandom(-10,10); 
      yt = fy->GetRandom(-10,10);
      x[i] = TMath::Cos( adhocrot )*xt + TMath::Sin( adhocrot )*yt; 
      y[i] =-TMath::Sin( adhocrot )*xt + TMath::Cos( adhocrot )*yt; 
      if ( TMath::Abs(y[i])>1e-8 ) {
	phi[i] = TMath::ATan ( y[i] / x[i] ); 
      }else{
	phi[i] = 0; 
      }
      hphis->Fill(phi[i]); 
      cout<<"x = "<<x[i]<<"\t, y = "<<y[i]<<", phi = "<<phi[i]<<endl;
    }

    cout<<"Computing Angle..."<<endl;
    
    Double_t lNumerator = 0; 
    Double_t lDenominator = 0; 
    
    for( long i=0; i<lNpts; i++){ 
      lNumerator   += TMath::Sin( 2. * phi[i] ); 
      lDenominator += TMath::Cos( 2. * phi[i] ); 
    }
    cout<<"numerator = "<<lNumerator<<endl;
    cout<<"denominator = "<<lDenominator<<endl;
    Double_t lAngle = TMath::ATan( lNumerator / lDenominator ) / 2 ; 

    cout<<"found angle = "<<lAngle<<endl;
    cout<<" In degrees = "<< 180.*lAngle/(TMath::Pi()) <<endl;
    
    TCanvas *c = new TCanvas ("c", "",600,600); 
    c->SetTicks( 1,1  ) ; 
    
    TH1D *hdum = new TH1D("hdum","",100,-10,10); 
    hdum->GetYaxis()->SetRangeUser(-10,10); 
    hdum->Draw(); 
    
    TGraph *g = new TGraph(lNpts, x, y); 
    g->SetMarkerStyle(20); 
    g->SetMarkerSize(0.67);
    g->Draw("P"); 

    //Drawing ... 
    Double_t xp[2], yp[2]; 
    Double_t lLength = 5; 
    
    xp[0] =  lLength * TMath::Cos(lAngle);  
    yp[0] =  lLength * TMath::Sin(lAngle);  
    
    xp[1] = - lLength * TMath::Cos(lAngle);  
    yp[1] = - lLength * TMath::Sin(lAngle);  
    
    TLine *ll = new TLine( xp[0], yp[0], xp[1], yp[1] ); 
    ll->SetLineStyle(7); 
    ll->SetLineColor(kRed+1); 
    ll->SetLineWidth(3); 
    ll->Draw(); 
    
    TCanvas *cc = new TCanvas("cc", "",800,600);
    cc->SetTicks(1,1); 
    hphis->Draw(); 
}
